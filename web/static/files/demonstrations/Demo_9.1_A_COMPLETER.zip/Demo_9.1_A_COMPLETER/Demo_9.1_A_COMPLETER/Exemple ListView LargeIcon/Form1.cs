namespace Exemple_ListView_LargeIcon
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            // �tape 0 : Cr�er une ListView et placer les images des plan�tes au niveau de l'ex�cutable


            // �tape 1 : Configurer le mode d'affichage



            // �tape 2 : Cr�er et configurer la liste d'images



            // �tape 3 : Ajouter des images


            // �tape 4 : Assigner votre liste d'images � la propri�t� `LargeImageList` de votre **`ListView`**



            // �tape 5 : Cr�er et ajouter des items 




        }
    }
}
