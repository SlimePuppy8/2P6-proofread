﻿namespace Exemple_CheckListBox
{
    partial class FrmPrincipal
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.clbFruitsEtLegumes = new System.Windows.Forms.CheckedListBox();
            this.btnAfficherItem = new System.Windows.Forms.Button();
            this.btnEtatItem = new System.Windows.Forms.Button();
            this.btnDécocherItem = new System.Windows.Forms.Button();
            this.btnCocherItem = new System.Windows.Forms.Button();
            this.btnNbItemsCoché = new System.Windows.Forms.Button();
            this.btnNbItems = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // clbFruitsEtLegumes
            // 
            this.clbFruitsEtLegumes.CheckOnClick = true;
            this.clbFruitsEtLegumes.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clbFruitsEtLegumes.FormattingEnabled = true;
            this.clbFruitsEtLegumes.Location = new System.Drawing.Point(16, 55);
            this.clbFruitsEtLegumes.Margin = new System.Windows.Forms.Padding(4);
            this.clbFruitsEtLegumes.Name = "clbFruitsEtLegumes";
            this.clbFruitsEtLegumes.Size = new System.Drawing.Size(235, 229);
            this.clbFruitsEtLegumes.TabIndex = 0;
            // 
            // btnAfficherItem
            // 
            this.btnAfficherItem.Location = new System.Drawing.Point(276, 57);
            this.btnAfficherItem.Margin = new System.Windows.Forms.Padding(4);
            this.btnAfficherItem.Name = "btnAfficherItem";
            this.btnAfficherItem.Size = new System.Drawing.Size(471, 34);
            this.btnAfficherItem.TabIndex = 4;
            this.btnAfficherItem.Text = "Afficher les items de la CheckListBox";
            this.btnAfficherItem.UseVisualStyleBackColor = true;
            this.btnAfficherItem.Click += new System.EventHandler(this.BtnAfficherItems_Click);
            // 
            // btnEtatItem
            // 
            this.btnEtatItem.Location = new System.Drawing.Point(276, 223);
            this.btnEtatItem.Margin = new System.Windows.Forms.Padding(4);
            this.btnEtatItem.Name = "btnEtatItem";
            this.btnEtatItem.Size = new System.Drawing.Size(471, 34);
            this.btnEtatItem.TabIndex = 5;
            this.btnEtatItem.Text = "Obtenir l\'état du premier item";
            this.btnEtatItem.UseVisualStyleBackColor = true;
            this.btnEtatItem.Click += new System.EventHandler(this.BtnAfficherEtatItem_Click);
            // 
            // btnDécocherItem
            // 
            this.btnDécocherItem.Location = new System.Drawing.Point(276, 181);
            this.btnDécocherItem.Margin = new System.Windows.Forms.Padding(4);
            this.btnDécocherItem.Name = "btnDécocherItem";
            this.btnDécocherItem.Size = new System.Drawing.Size(471, 34);
            this.btnDécocherItem.TabIndex = 6;
            this.btnDécocherItem.Text = "Décocher le premier item";
            this.btnDécocherItem.UseVisualStyleBackColor = true;
            this.btnDécocherItem.Click += new System.EventHandler(this.BtnDécocherItem_Click);
            // 
            // btnCocherItem
            // 
            this.btnCocherItem.Location = new System.Drawing.Point(276, 139);
            this.btnCocherItem.Margin = new System.Windows.Forms.Padding(4);
            this.btnCocherItem.Name = "btnCocherItem";
            this.btnCocherItem.Size = new System.Drawing.Size(471, 34);
            this.btnCocherItem.TabIndex = 7;
            this.btnCocherItem.Text = "Cocher le premier item";
            this.btnCocherItem.UseVisualStyleBackColor = true;
            this.btnCocherItem.Click += new System.EventHandler(this.BtnCocherItem_Click);
            // 
            // btnNbItemsCoché
            // 
            this.btnNbItemsCoché.Location = new System.Drawing.Point(276, 265);
            this.btnNbItemsCoché.Margin = new System.Windows.Forms.Padding(4);
            this.btnNbItemsCoché.Name = "btnNbItemsCoché";
            this.btnNbItemsCoché.Size = new System.Drawing.Size(471, 34);
            this.btnNbItemsCoché.TabIndex = 8;
            this.btnNbItemsCoché.Text = "Afficher le nombre d\'items cochés";
            this.btnNbItemsCoché.UseVisualStyleBackColor = true;
            this.btnNbItemsCoché.Click += new System.EventHandler(this.BtnNbItemsCochés_Click);
            // 
            // btnNbItems
            // 
            this.btnNbItems.Location = new System.Drawing.Point(276, 97);
            this.btnNbItems.Margin = new System.Windows.Forms.Padding(4);
            this.btnNbItems.Name = "btnNbItems";
            this.btnNbItems.Size = new System.Drawing.Size(471, 34);
            this.btnNbItems.TabIndex = 9;
            this.btnNbItems.Text = "Obtenir le nombre d\'items";
            this.btnNbItems.UseVisualStyleBackColor = true;
            this.btnNbItems.Click += new System.EventHandler(this.BtnNbItems_Click);
            // 
            // FrmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(760, 336);
            this.Controls.Add(this.btnNbItems);
            this.Controls.Add(this.btnNbItemsCoché);
            this.Controls.Add(this.btnCocherItem);
            this.Controls.Add(this.btnDécocherItem);
            this.Controls.Add(this.btnEtatItem);
            this.Controls.Add(this.btnAfficherItem);
            this.Controls.Add(this.clbFruitsEtLegumes);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "FrmPrincipal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CheckListBox ";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.CheckedListBox clbFruitsEtLegumes;
        private System.Windows.Forms.Button btnAfficherItem;
        private System.Windows.Forms.Button btnEtatItem;
        private System.Windows.Forms.Button btnDécocherItem;
        private System.Windows.Forms.Button btnCocherItem;
        private System.Windows.Forms.Button btnNbItemsCoché;
        private System.Windows.Forms.Button btnNbItems;
    }
}

