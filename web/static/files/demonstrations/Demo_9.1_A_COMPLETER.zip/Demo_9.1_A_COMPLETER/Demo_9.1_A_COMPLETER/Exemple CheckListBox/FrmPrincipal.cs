﻿using System;
using System.Collections.ObjectModel;
using System.Windows.Forms;

namespace Exemple_CheckListBox
{
    public partial class FrmPrincipal : Form
    {
        public const string APP_INFO = "(Matériel)";
        //----------------------------------------------------------------------------------------
        public FrmPrincipal()
        {
            InitializeComponent();
            Text += APP_INFO;

            // TODO 01 : Ajouter des éléments dans la CheckListBox

            

        }

        private void BtnAfficherItems_Click(object sender, EventArgs e)
        {
            // TODO 02 : Afficher les items de la CheckListBox dans un MessageBox

            
        }

        private void BtnNbItems_Click(object sender, EventArgs e)
        {
            // TODO 03 : Obtenir le nombre d'items dans la CheckListBox
           
        }

        private void BtnCocherItem_Click(object sender, EventArgs e)
        {
            // TODO 04 : Cocher le premier item


        }

        private void BtnDécocherItem_Click(object sender, EventArgs e)
        {
            // TODO 05 : Décocher le premier item

            
        }

        private void BtnAfficherEtatItem_Click(object sender, EventArgs e)
        {
            
            // TODO 06 : Afficher l'état du premier item
            
        }

        private void BtnNbItemsCochés_Click(object sender, EventArgs e)
        {
            
            // TODO 07 : Afficher le nombre d'items cochés dans le CheckListBox 

            
        }
    }
}