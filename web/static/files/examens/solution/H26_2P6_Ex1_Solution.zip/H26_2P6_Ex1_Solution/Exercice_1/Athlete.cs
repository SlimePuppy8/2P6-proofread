﻿
namespace Exercice_1
{

    /// ------------------------------------------------------------------------------
    /// <summary>
    ///	 Représente un athète : son nom, son prénom, son âge, et son temps obtenu (en secondes)
    /// </summary>
    /// ------------------------------------------------------------------------------
    public class Athlete
    {
        public const string NOM_PAR_DEFAUT = "Inconnu";
        public const string PRENOM_PAR_DEFAUT = "Inconnu";
        public const int AGE_PAR_DEFAUT = 18;
        public const double TEMPS_PAR_DEFAUT = 59.999;

        /// <summary>
        /// Nom de l'athlète.
        /// </summary>
        public string Nom { get; }

        /// ----------------------------------------------------
        /// <summary>
        /// Prénom de l'athlète.
        /// </summary>
        public string Prenom { get; }

        /// ----------------------------------------------------
        /// <summary>
        /// Obtient et définit l'age d'un athlète.
        /// </summary>
        /// ----------------------------------------------------
        public int Age { get; set; }

        /// ----------------------------------------------------
        /// <summary>
        /// Temps obtenu en secondes.
        /// </summary>
        public double Temps { get; }

        //---------------------------------------------------------------
        /// <summary>
        /// Instancie un athlète avec les données passées en paramètre.
        /// </summary>
        /// <param name="pNom">nom de l'athlète à créer</param>
        /// <param name="pPrenom">prénom de l'athlète à créer</param>
        /// <param name="pAge">age de l'athlète à créer</param>
        /// <param name="pPays">pays représenté par l'athlète à créer</param>
        /// <param name="pTemps">temps obtenu par l'athlète à créer</param>
        /// -------------------------------------------------------------
        public Athlete(string pNom, string pPrenom, int pAge, double pTemps)
        {

            Nom = pNom;
            Prenom = pPrenom;
            Age = pAge;
            Temps = pTemps;

        }

        //---------------------------------------------------------------
        /// <summary>
        /// Instancie un athlète avec les valeurs par défaut.
        /// </summary>
        /// -------------------------------------------------------------
        public Athlete()
        {
            Nom = NOM_PAR_DEFAUT;
            Prenom = PRENOM_PAR_DEFAUT;
            Age = AGE_PAR_DEFAUT;
            Temps = TEMPS_PAR_DEFAUT;

        }




    }
}
