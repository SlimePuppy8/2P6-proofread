﻿// Décommenter pour activer les tests d'une méthode
//#define TEST_CHARGER
//#define TEST_AJOUTER_ATHLETE
//#define TEST_MODIFIER_AGE
//#define TEST_FILTRER_TEMPS
//#define TEST_MEILLEUR_TEMPS


using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using Exercice_1;
using static System.Formats.Asn1.AsnWriter;


public static class TestsAthletes
{
    public static int totalTests = 0;
    public static int testsReussis = 0;




    #region Tests de validation
    // ==========================================================
    static void AfficherResultat(bool condition, string message)
    {
        totalTests++;

        if (condition)
        {
            testsReussis++;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("OK");
        }
        else
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("ERREUR: "+message);
        }

        Console.ResetColor();
    }
   
    // ==========================================================
    static void AfficherResultat(bool condition)
    {
        totalTests++;

        if (condition)
        {
            testsReussis++;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("OK");
        }
        else
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("ERREUR");
        }

        Console.ResetColor();
    }

    // ==========================================================
    static List<Athlete> CreerListeTest()
    {
        return new List<Athlete>()
        {
            new Athlete("DUBOIS", "Steven", 28, 40.835),
            new Athlete("VAN'T WOUT", "Melle", 26, 40.912),
            new Athlete("VAN'T WOUT", "Jens", 24, 41.908),
            new Athlete("BOER", "Teun", 24, 40.295),
            new Athlete("DANDJINOU", "William", 24, 40.752),
            new Athlete("LIU", "Shaoang", 27, 41.525),
            new Athlete("NIKISHA", "Denis", 30, 41.948),
            new Athlete("PIGEON", "Felix", 23, 45.345),
            new Athlete("NADALINI", "Thomas", 23, 40.921),
            new Athlete("YOSHINAGA", "Kazuki", 26, 40.895)
        };
    }

// ==========================================================
    public static void TestAjouterAthlete()
    {

#if TEST_AJOUTER_ATHLETE
        Console.WriteLine("\n===== TEST AjouterAthlete =====");
        var liste = CreerListeTest();
        AfficherResultat(
           !Program.AjouterAthlete(null, "David", 27, 39.909, liste)
           && liste.Count == 10, "Le nom ne doit pas être null! Une validation manque ici!");
        liste = CreerListeTest();
        AfficherResultat(
           !Program.AjouterAthlete("", "David", 27, 39.909, liste)
           && liste.Count == 10, "Le nom ne doit pas être vide! Une validation manque ici!");
        liste = CreerListeTest();
        AfficherResultat(
           !Program.AjouterAthlete("GAGNÉ-LEROU", null, 27, 39.909, liste)
           && liste.Count == 10, "Le prénom ne doit pas être null! Une validation manque ici!");
        liste = CreerListeTest();
        AfficherResultat(
           !Program.AjouterAthlete("GAGNÉ-LEROU", "", 27, 39.909, liste)
           && liste.Count == 10, "Le prénom ne doit pas être vide! Une validation manque ici!");
        liste = CreerListeTest();
        AfficherResultat(
           !Program.AjouterAthlete("GAGNÉ-LEROU", "David", -1, 39.909, liste)
           && liste.Count == 10, "L'age ne doit pas être plus petit que 18! Une validation manque ici!");
        liste = CreerListeTest();
        AfficherResultat(
           !Program.AjouterAthlete("GAGNÉ-LEROU", "David", 27, 0, liste)
           && liste.Count == 10, "Le temps obtenu ne doit pas être plus petit ou égal à zéro! Une validation manque ici!");
        try
        {
            liste = CreerListeTest();
            AfficherResultat(
               !Program.AjouterAthlete("GAGNÉ-LEROU", "David", 27, 39.909, null)
               && liste.Count == 10, "");
        }
        catch (Exception e)
        {
           
            AfficherResultat(false, "La liste ne doit pas être à null! Une validation manque ici!");
        }

        liste = CreerListeTest();
        AfficherResultat(
            Program.AjouterAthlete("GAGNÉ-LEROUX", "David", 27, 39.909, liste)
            && liste.Count == 11);


#endif
    }

// ==========================================================
    public static void TestModifierAge()
    {

#if TEST_MODIFIER_AGE
        Console.WriteLine("\n===== TEST ModifierAge =====");
        var liste = CreerListeTest();
        List<Athlete> copie;



        try
        {
            liste = CreerListeTest();
            copie = CopierListe(liste);
            AfficherResultat(
                  Program.ModifierAge(-1, 23, liste)
                  || ComparerListes(liste, copie), "L'index doit être valide! Une validation manque ici!");
        }
        catch (Exception e)
        {

            AfficherResultat(false, "L'index doit être valide! Une validation manque ici!");
        }

        liste = CreerListeTest();
        copie = CopierListe(liste);
        AfficherResultat(
              !(Program.ModifierAge(1, 17, copie) && !ComparerListes(liste, copie)), "L'age doit être valide! Une validation manque ici!");

       

        try
        {
            liste = CreerListeTest();
            copie = CopierListe(liste);
            Program.ModifierAge(1, 18, null);
           
        }
        catch (Exception e)
        {

            AfficherResultat(false, "La liste ne doit pas être null! Une validation manque ici!");
        }

        liste = CreerListeTest();
        copie = CopierListe(liste);
        AfficherResultat(
              (Program.ModifierAge(1, 18, liste) && (liste[1].Age==18)), "La modification d'age n'est pas effectuee correctement!");

#endif
    }


    // ==========================================================
    public static void TestFiltrerSelonTemps()
    {

#if TEST_FILTRER_TEMPS
        Console.WriteLine("\n===== TEST FiltrerSelonTemps =====");
        var liste = CreerListeTest();


        try
        {
            var filtres = Program.FiltrerSelonTemps(40.0, 40.9, null);
            AfficherResultat(filtres  != null && filtres.Count == 0, "On retourne une liste vide quand la liste en entrée est à null!");

        }
        catch (Exception e)
        {

            AfficherResultat(false, "La liste en entrée ne doit pas être null! Une validation manque ici!");
        }


        liste = CreerListeTest();       
        var filtres1 = Program.FiltrerSelonTemps(40.0, 40.9, liste);

        AfficherResultat(filtres1.Count == 4, "Resultat incorrect!");

       

#endif

    }

    // ==========================================================
    public static void TestTempsLePlusRapide()
    {

#if TEST_MEILLEUR_TEMPS
        Console.WriteLine("\n===== TEST TempsLePlusRapide =====");
        var liste = CreerListeTest();

        try
        {
            double meilleurTempsNull = Program.TempsLePlusRapide(null);
            AfficherResultat((meilleurTempsNull != null && meilleurTempsNull == 0), "On retourne la valeur 0 quand la liste en entrée est à null!");
        }
        catch (Exception e)
        {

            AfficherResultat(false, "La liste en entrée ne doit pas être null! Une validation manque ici!");
        }

        liste = CreerListeTest();
        liste.Clear();
      

        try
        {
            double meilleurTempsVide = Program.TempsLePlusRapide(liste);

            AfficherResultat(meilleurTempsVide == 0, "On retourne la valeur 0 quand la liste en entrée est à vide!");

        }
        catch (Exception e)
        {

            AfficherResultat(false, "On retourne la valeur 0 quand la liste en entrée est à vide!!");
        }
        liste = CreerListeTest();
        try
        {
            double meilleurTempsVide = Program.TempsLePlusRapide(liste);
            double attendu = liste.Min(x => x.Temps);
            AfficherResultat(meilleurTempsVide == attendu, "Resultat incorrect!");

        }
        catch (Exception e)
        {

            AfficherResultat(false, "Autre!");
        }


#endif
    }


    // ==========================================================
    public static void TestCharger()
    {
#if TEST_CHARGER
        Console.WriteLine("\n===== TEST Charger =====");

        // 1) Préparer un fichier de test
        string fichier = "testChargement.csv";
        File.WriteAllLines(fichier, new string[]
        {
        "DUBOIS;Steven;28;40,835",
        "VAN'T WOUT;Melle;26;40,912",
        "VAN'T WOUT;Jens;24;41,908"
        });

        // 2) Appeler la méthode à tester
        List<Athlete> liste = new List<Athlete>();
        Program.Charger(fichier, liste);

        // 3) Vérification BRUTE (non réutilisable, volontairement)
        bool ok = true;

        if (liste.Count != 3)
        {
            ok = false;
        }
        else
        {
            // Lecture directe du fichier, sans structure élégante
            string[] lignes = File.ReadAllLines(fichier);

            for (int i = 0; i < lignes.Length; i++)
            {
                string[] morceaux = lignes[i].Split(';');

                if (liste[i].Nom != morceaux[0] ||
                    liste[i].Prenom != morceaux[1] ||
                    liste[i].Age != int.Parse(morceaux[2]) ||
                    liste[i].Temps != double.Parse(morceaux[3]))
                {
                    ok = false;
                    break;
                }
            }
        }

        AfficherResultat(ok);
#endif
    }

    #endregion

    public static List<Athlete> CopierListe(List<Athlete> pListe)
    {
        List<Athlete> copie = new List<Athlete>();

        foreach (Athlete a in pListe)
        {
            Athlete nouvelAthlete = new Athlete(
                a.Nom,
                a.Prenom,
                a.Age,
                a.Temps
            );

            copie.Add(nouvelAthlete);
        }

        return copie;
    }
    public static bool ComparerListes(List<Athlete> liste1, List<Athlete> liste2)
    {
        // Cas simples
        if (liste1 == null || liste2 == null)
            return false;

        if (liste1.Count != liste2.Count)
            return false;

        // Comparaison élément par élément
        for (int i = 0; i < liste1.Count; i++)
        {
            Athlete a1 = liste1[i];
            Athlete a2 = liste2[i];

            if (a1.Nom != a2.Nom ||
                a1.Prenom != a2.Prenom ||
                a1.Age != a2.Age ||
                a1.Temps != a2.Temps)
            {
                return false;
            }
        }

        return true;
    }
}
