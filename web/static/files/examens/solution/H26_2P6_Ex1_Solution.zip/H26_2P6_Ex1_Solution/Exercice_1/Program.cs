﻿

namespace Exercice_1
{
    class Program
    {
        public const string CSV_DES_ATHLETES = "../../ResultatsFinaleHomme.csv";

        static private List<Athlete> listeAthletes = new List<Athlete>();

        static void Main(string[] args)
        {
            TestsAthletes.TestCharger();
            TestsAthletes.TestAjouterAthlete();
            TestsAthletes.TestModifierAge();
            TestsAthletes.TestFiltrerSelonTemps();
            TestsAthletes.TestTempsLePlusRapide();


            Console.WriteLine("\n===================================");
            Console.WriteLine($"RÉSULTAT FINAL : {TestsAthletes.testsReussis} / {TestsAthletes.totalTests}");
            Console.WriteLine("===================================");

            Console.ReadLine();
        }

        #region Méthodes à implémenter


        /// <summary>
        /// TODO 01 : Charge les athlètes à partir d'un fichier csv et les ajoute dans la liste fournie.
        /// </summary> 
        /// <param name="pNomDuFichier"> Nom ou chemin du fichier source. </param>
        /// <param name="pListeAthletes"> Liste dans laquelle ajouter les athlètes chargés. </param>
        /// <remarks>
        /// Chaque ligne du fichier contient les informations d'un athlète sous le format : NOM;Prenom;Age;Temps
        /// Vous devez vérifier que le fichier passé en paramètre existe. Si le fichier n'existe pas, un message doit être affiché.
        /// </remarks>
        static public void Charger(string pNomDuFichier, List<Athlete> pListeAthletes)
        {

            if (!File.Exists(pNomDuFichier))
            {
                Console.WriteLine("Impossible de trouver le fichier contenant les athlètes.");
                return;
            }


            using (StreamReader reader = new StreamReader(pNomDuFichier))
            {
                while (!reader.EndOfStream)
                {
                    string ligne = reader.ReadLine();

                    string[] tab = ligne.Split(';');

                    string nom = tab[0];
                    string prenom = tab[1];
                    int age = int.Parse(tab[2]);
                    double temps = double.Parse(tab[3]); ;

                    Athlete athlete = new Athlete(nom, prenom, age, temps);
                    pListeAthletes.Add(athlete);

                }
            }
        }

        /// <summary>
        /// TODO 02 : Ajoute un nouvel athlete dans la liste.
        /// </summary>
        /// <param name="pNom">Nom de l'athlète.</param>
        /// <param name="pPrenom">Prénom de l'athlète.</param>
        /// <param name="pAge">Âge de l'athlète.</param>
        /// <param name="pTemps">Temps obtenu par l'athlète.</param>
        /// <param name="pListeAthletes">Liste dans laquelle ajouter le nouvel athlète.</param>
        /// <returns>
        /// Retourne true si l'athlète est ajouté avec succès.
        /// Retourne false si la liste en paramètre est null.
        /// </returns>
        static public bool AjouterAthlete(string pNom, string pPrenom, int pAge, double pTemps, List<Athlete> pListeAthletes)
        {
            if (pNom == null || pNom == "")
            {
                return false;
            }
            if (pPrenom == null || pPrenom == "")
            {
                return false;
            }
            if (pAge < 18)
            {
                return false;
            }
            if (pTemps <= 0)
            {
                return false;
            }
            if (pListeAthletes == null)
            {
                return false;
            }
            Athlete nouvelAthlete = new Athlete(pNom, pPrenom, pAge, pTemps);
            pListeAthletes.Add(nouvelAthlete);
            return true;
        }


        /// <summary>
        /// TODO 03 : Modifier l'âge d'un athlète de la liste selon son index.
        /// </summary>
        /// <param name="index"> Position de l'athlète dans la liste. </param>
        /// <param name="nouvelAge"> Nouvel age de l'athlète. </param>
        /// <param name="pListeAthletes"> Liste dans laquelle modifier l'athlète.</param>
        /// <returns>
        /// Retourne true si la modification est effectuée.
        /// Retourne false si l'index est invalide, l'age est invalide ou la liste est a null.
        /// </returns>
        /// <remarks>
        /// L'index doit être compris entre 0 et pListeAthletes.Count - 1.
        /// </remarks>
        static public bool ModifierAge(int index, int nouvelAge, List<Athlete> pListeAthletes)
        {
            if (pListeAthletes == null)
                return false;
            if (index < 0 || index >= pListeAthletes.Count)
                return false;
            if (nouvelAge < 18)
                return false;


            pListeAthletes[index].Age = nouvelAge;

            return true;
        }


        /// <summary>
        /// TODO 04 : Retourne une nouvelle liste contenant uniquement les athlètes
        /// ayant obtenu un temps entre tempsMin et tempsMax inclusivement.
        /// </summary>
        /// <param name="tempsMin"> Temps minimum (inclus).</param>
        /// <param name="tempsMax">Temps maximum (inclus).</param>
        /// <param name="pListeAthletes">Liste originale à filtrer.</param>
        /// <returns>
        /// Une nouvelle liste contenant les athlètes correspondant à la tranche de temps spécifiée.
        /// </returns>
        /// <remarks>
        /// Utiliser une boucle (while/for/foreach).
        /// Si la liste à filtrer est null, retourner une liste vide.
        /// La liste originale n'est pas modifiée.
        /// </remarks>
        static public List<Athlete> FiltrerSelonTemps(double tempsMin, double tempsMax, List<Athlete> pListeAthletes)
        {
            List<Athlete> listeAthletesFiltres = new List<Athlete>();

            if (pListeAthletes == null)
            {
                return listeAthletesFiltres;
            }

            foreach (Athlete athlete in pListeAthletes)
            {
                if (athlete.Temps >= tempsMin && athlete.Temps <= tempsMax)
                {
                    listeAthletesFiltres.Add(athlete);
                }
            }
          
            return listeAthletesFiltres;
        }
        /// <summary>
        /// TODO 05 : Trouve et retourne le temps le plus rapide parmi les athlètes.
        /// </summary>
        /// <param name="pListeAthletes">Liste des athlètes</param>
        /// <returns>
        /// Le temps le plus rapide (le plus petit).
        /// Retourne 0 si la liste est vide ou null.
        /// </returns>
        /// <remarks>
        /// Utiliser une boucle (while/for/foreach).
        /// Le temps le plus rapide correspond à la plus petite valeur
        /// de temps dans la liste des athlètes.
        /// </remarks>
        static public double TempsLePlusRapide(List<Athlete> pListeAthletes)
        {
            if (pListeAthletes == null || pListeAthletes.Count == 0)
            {
                return 0;
            }
            double meilleurTemps = pListeAthletes[0].Temps;

            foreach (Athlete athlete in pListeAthletes)
            {
                if (athlete.Temps < meilleurTemps)
                {
                    meilleurTemps = athlete.Temps;
                }
            }

            return meilleurTemps;
        }




        #endregion
    }
}
