﻿namespace Exercice_2
{

    class Program
    {
        static void Main(string[] args)
        {
            TestsPatineur.TestConstructeur();
            TestsPatineur.TestAjouterAcrobatie();
            TestsPatineur.TestViderProgramme();
            TestsPatineur.TestPointage();
            TestsPatineur.TestNom();
            TestsPatineur.TestPrenom();

            Console.WriteLine("\n===================================");
            Console.WriteLine($"RÉSULTAT FINAL : {TestsPatineur.testsReussis} / {TestsPatineur.totalTests}");
            Console.WriteLine("===================================");

            Console.ReadLine();

        }

       
    }
}
