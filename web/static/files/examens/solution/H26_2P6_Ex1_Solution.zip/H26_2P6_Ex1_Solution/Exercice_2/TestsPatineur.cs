﻿// Décommenter pour activer les tests d'une méthode
//#define TEST_CONSTRUCTEUR
//#define TEST_AJOUTER_ACROBATIE
//#define TEST_VIDER_PROGRAMME
//#define TEST_POINTAGE
//#define TEST_TOSTRING
//#define TEST_NOM
//#define TEST_PRENOM

using Exercice_2;

public static class TestsPatineur
{
    public static int totalTests = 0;
    public static int testsReussis = 0;
  
    // ==========================================================

    static void AfficherResultat(bool condition, string message)
    {
        totalTests++;

        if (condition)
        {
            testsReussis++;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("OK");
        }
        else
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("ERREUR: " + message);
        }

        Console.ResetColor();
    }

    // ==========================================================
    static void AfficherResultat(bool condition)
    {
        totalTests++;

        if (condition)
        {
            testsReussis++;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("OK");
        }
        else
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("ERREUR");
        }

        Console.ResetColor();
    }

    // ==========================================================
    static Patineur CreerPatineurTest()
    {
        var programme = new List<Acrobaties>()
        {
            Acrobaties.SautSimple,
            Acrobaties.SautDouble,   
            Acrobaties.PirouetteSimple 
        };

        return new Patineur("Martel", "Philippe", programme);
    }

    // ==========================================================
    public static void TestConstructeur()
    {
#if TEST_CONSTRUCTEUR
        Console.WriteLine("\n===== TEST Constructeur =====");

        Patineur p = new Patineur();

        AfficherResultat(p.Nom == Patineur.NOM_PAR_DEFAUT);
        AfficherResultat(p.Prenom == Patineur.PRENOM_PAR_DEFAUT);
        AfficherResultat(p.Programme.Count == 0);
#endif
    }

    // ==========================================================
    public static void TestAjouterAcrobatie()
    {
#if TEST_AJOUTER_ACROBATIE
        Console.WriteLine("\n===== TEST AjouterAcrobatie =====");

        Patineur p = new Patineur();

        p.AjouterAcrobatie(Acrobaties.SautTriple);

        //AfficherResultat(p.Programme.Count == 1);
        AfficherResultat(p != null && p.Programme != null && p.Programme.Count==1 && p.Programme[0] == Acrobaties.SautTriple, "Problème dans l’ajout d’une acrobatie!");
#endif
    }

    // ==========================================================
    public static void TestViderProgramme()
    {
#if TEST_VIDER_PROGRAMME
        Console.WriteLine("\n===== TEST ViderProgramme =====");

        Patineur p = CreerPatineurTest();

        p.ViderProgramme();

        AfficherResultat(p.Programme != null && p.Programme.Count == 0, "La liste des programmes n’est pas correctement vidée!");
#endif
    }

    // ==========================================================
    public static void TestPointage()
    {
#if TEST_POINTAGE
        Console.WriteLine("\n===== TEST Pointage =====");

        Patineur p = CreerPatineurTest();

        AfficherResultat(p.Pointage == 11);

        p.AjouterAcrobatie(Acrobaties.AxelTriple);

        AfficherResultat(p.Pointage == 26);
#endif
    }

    // ==========================================================
    public static void TestNom()
    {
#if TEST_NOM
        Console.WriteLine("\n===== TEST NOM =====");
        Console.WriteLine("\n===== On teste la modification du nom! =====");
        Patineur p = CreerPatineurTest();
        p.Nom = null;
        AfficherResultat(p.Nom != null, "Nom ne doit pas être null! Une validation manque ici!");

        p.Nom = "a";
        AfficherResultat(p.Nom != "a", "Nom doit contenir au moins 3 caractères! Une validation manque ici!");

        p.Nom = "Montgomerywilliamsonfitzgeralda";
        AfficherResultat(!(p.Nom == "Montgomerywilliamsonfitzgeralda"), "Nom doit contenir au maximum 30 caractères! Une validation manque ici!");
        p.Nom = "Gammoudi";
        AfficherResultat(p.Nom == "Gammoudi", "");


#endif
    }
    public static void TestPrenom()
    {
#if TEST_PRENOM
        Console.WriteLine("\n===== TEST PRENOM =====");
        Console.WriteLine("\n===== On teste la modification du prénom! =====");
        Patineur p = CreerPatineurTest();
        p.Prenom = null;
        AfficherResultat(p.Prenom != null, "Le prénom ne doit pas être null! Une validation manque ici!");

        p.Prenom = "a";
        AfficherResultat(p.Prenom != "a", "Le prénom doit contenir au moins 3 caractères! Une validation manque ici!");

        p.Prenom = "Montgomerywilliamsonfitzgeralda";
        AfficherResultat(!(p.Prenom == "Montgomerywilliamsonfitzgeralda"), "La prénom doit contenir au maximum 30 caractères! Une validation manque ici!");
        p.Prenom = "Jamil";
        AfficherResultat(p.Prenom == "Jamil", "");


#endif
    }
    // ==========================================================

}
