﻿namespace Exercice_2
{
    public enum Acrobaties
    {
        PirouetteSimple,
        PirouetteCombinee,
        SautSimple,
        SautDouble,
        SautTriple,
        Axel,
        AxelDouble,
        AxelTriple
    }

    public class Patineur
    {

        public const string NOM_PAR_DEFAUT = "Inconnu";
        public const string PRENOM_PAR_DEFAUT = "Inconnu";

        private string m_nom;
        private string m_prenom;
        private List<Acrobaties> m_programme;


        public string Nom
        {
            get { return m_nom; }
            set {

                if (value == null || value.Length < 3 || value.Length > 30)
                {
                    m_nom = NOM_PAR_DEFAUT;
                }
                else
                {
                    m_nom = value;
                }

            }
        }

        public string Prenom
        {
            get { return m_prenom; }
            set {

                if (value == null || value.Length < 3 || value.Length > 30)
                {
                    m_prenom = PRENOM_PAR_DEFAUT;
                }
                else
                {
                    m_prenom = value;
                }

            }
        }

        public List<Acrobaties> Programme
        {
            get { return m_programme; }
            private set { m_programme = value; }
        }

        public int Pointage
        {
            get
            {
                int total = 0;

                foreach (Acrobaties acrobatie in m_programme)
                {
                    total += CalculerPoints(acrobatie);
                }

                return total;
            }
        }


        public Patineur()
        {
            m_nom = NOM_PAR_DEFAUT;
            m_prenom = PRENOM_PAR_DEFAUT;
            m_programme = new List<Acrobaties>();
        }

        public Patineur(string pNom, string pPrenom, List<Acrobaties> pProgramme)
        {
            Nom = pNom;
            Prenom = pPrenom;
            Programme = pProgramme;
        }

        public void AjouterAcrobatie(Acrobaties acrobatie)
        {
            m_programme.Add(acrobatie);
        }

        public void ViderProgramme()
        {
            m_programme.Clear();
        }


        private int CalculerPoints(Acrobaties acrobatie)
        {
            switch (acrobatie)
            {
                case Acrobaties.PirouetteSimple:
                    return 2;

                case Acrobaties.PirouetteCombinee:
                    return 4;

                case Acrobaties.SautSimple:
                    return 3;

                case Acrobaties.SautDouble:
                    return 6;

                case Acrobaties.SautTriple:
                    return 10;

                case Acrobaties.Axel:
                    return 5;

                case Acrobaties.AxelDouble:
                    return 9;

                case Acrobaties.AxelTriple:
                    return 15;

                default:
                    return 0;
            }
        }

    }
}
