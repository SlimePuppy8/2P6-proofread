using System;

namespace Exer02_ListView_LargeIcon
{
    public partial class Form1 : Form
    {

        private List<string> acteurs = new List<string>();
        public Form1()
        {
            InitializeComponent();


            ChargerListeActeurs();


            AfficherListeActeurs();


        }

        #region ChargerListeActeurs (� COMPL�TER...)
        //=====================================================================================
        /// <summary>
        /// TODO 01 : Charge la liste des acteurs � partir du fichier "Acteurs.txt".
        /// Utiliser un point d'arr�t afin de v�rifier le fonctionnement du chargement
        /// </summary>
        private void ChargerListeActeurs()
        {

        }
        #endregion

        #region AfficherListeActeurs (� COMPL�TER...)
        //=====================================================================================
        /// <summary>
        /// TODO 02 :Cr�e une ImageList dynamiquement qui contiendra les photos des acteurs (voir dossier Images)
        /// Affiche chaque acteur de la liste dans une ListeView utilisant l'option LargeIcon pour la propri�t� View. 
        /// Assigne � la propri�t� LargeImageList de la ListeView l'ImageList contenant les photos des acteurs.
        /// </summary>
        private void AfficherListeActeurs()
        {
            
        }
        #endregion

    }
}
