﻿using System;
using BuanderieApp;
namespace BuanderieApp
{
    class Program
    {
        /*
     * =========================================
     * TESTS POUR LA CLASSE SECHEUSE
     * =========================================
     * 💡 Indication pour les étudiants :
     * Ces tests console permettent de valider certaines fonctionnalités
     * de votre classe Secheuse : constructeur, propriétés et méthodes publiques.
     * 
     * ⚠️ Attention : Ces tests ne sont pas exhaustifs.
     * Ils ne couvrent pas tous les cas possibles. 
     * Utilisez-les comme guide et ajoutez vos propres tests
     * pour explorer d’autres situations (montants invalides, blocs supplémentaires, machine déjà en marche, etc.).
     */
        static void Main()
        {
            //            Console.WriteLine("====================================");
            //            Console.WriteLine(" VALIDATION CLASSE SECHEUSE");
            //            Console.WriteLine("====================================\n");

            //            TestConstructeur();
            //            TestProprieteCycleTemperature();
            //            TestMethodeAjouterMontant();
            //            TestMethodeDemarrer();
            //            TestConsommationMinutes();
            //            TestReinitialiser();

            //            Console.WriteLine("\nFIN DES TESTS");
            //            Console.ReadLine();
            //        }

            //        static void TestConstructeur()
            //        {
            //            Console.WriteLine("=== TEST CONSTRUCTEUR : Secheuse() ===");

            //            Secheuse s = new Secheuse();

            //            Console.WriteLine($"MontantTotal : {s.MontantTotal} (attendu: 0)");
            //            Console.WriteLine($"MinutesRestantes : {s.MinutesRestantes} (attendu: 0)");
            //            Console.WriteLine($"Cycle : {s.Cycle} (attendu: BlancsCouleurs)");
            //            Console.WriteLine($"Temperature : {s.Temperature} (attendu: 75)");
            //            Console.WriteLine($"EstEnMarche : {s.EstEnMarche} (attendu: False)\n");
            //        }

            //        static void TestProprieteCycleTemperature()
            //        {
            //            Console.WriteLine("=== TEST PROPRIÉTÉ : Cycle / Temperature ===");

            //            Secheuse s = new Secheuse();

            //            s.ChoisirCycle(CycleSechage.Synthetiques);
            //            Console.WriteLine($"Cycle : {s.Cycle} | Température : {s.Temperature} (attendu: {Secheuse.TEMP_SYNTHETIQUES})");

            //            s.ChoisirCycle(CycleSechage.Delicats);
            //            Console.WriteLine($"Cycle : {s.Cycle} | Température : {s.Temperature} (attendu: {Secheuse.TEMP_DELICATS})");

            //            s.ChoisirCycle(CycleSechage.BlancsCouleurs);
            //            Console.WriteLine($"Cycle : {s.Cycle} | Température : {s.Temperature} (attendu: {Secheuse.TEMP_BLANCS})\n");
            //        }

            //        static void TestMethodeAjouterMontant()
            //        {
            //            Console.WriteLine("=== TEST MÉTHODE : AjouterMontant(int) ===");

            //            Secheuse s = new Secheuse();

            //            s.AjouterMontant(100);
            //            Console.WriteLine($"Après 1$ -> Minutes : {s.MinutesRestantes} (attendu: 0)");

            //            s.AjouterMontant(100);
            //            Console.WriteLine($"Après 2$ -> Minutes : {s.MinutesRestantes} (attendu: 35)");

            //            s.AjouterMontant(25);
            //            Console.WriteLine($"Après 2.25$ -> Minutes : {s.MinutesRestantes} (attendu: 40)\n");
            //        }

            //        static void TestMethodeDemarrer()
            //        {
            //            Console.WriteLine("=== TEST MÉTHODE : Demarrer() ===");

            //            Secheuse s = new Secheuse();

            //            s.Demarrer();
            //            Console.WriteLine($"Sans argent -> EstEnMarche : {s.EstEnMarche} (attendu: False)");

            //            s.AjouterMontant(100);
            //            s.AjouterMontant(100);
            //            s.Demarrer();
            //            Console.WriteLine($"Avec montant suffisant -> EstEnMarche : {s.EstEnMarche} (attendu: True)\n");
            //        }

            //        static void TestConsommationMinutes()
            //        {
            //            Console.WriteLine("=== TEST MÉTHODE : ConsommerUneMinute() ===");

            //            Secheuse s = new Secheuse();

            //            s.AjouterMontant(200);
            //            s.Demarrer();

            //            Console.WriteLine($"Minutes initiales : {s.MinutesRestantes} (attendu: 35)");

            //            s.ConsommerUneMinute();
            //            Console.WriteLine($"Après 1 minute -> {s.MinutesRestantes} (attendu: 34)");

            //            while (s.MinutesRestantes > 0)
            //            {
            //                s.ConsommerUneMinute();
            //            }

            //            Console.WriteLine($"Après fin -> EstEnMarche : {s.EstEnMarche} (attendu: False)\n");
            //        }

            //        static void TestReinitialiser()
            //        {
            //            Console.WriteLine("=== TEST MÉTHODE : Reinitialiser() ===");

            //            Secheuse s = new Secheuse();

            //            s.AjouterMontant(200);
            //            s.Demarrer();
            //            s.Reinitialiser();

            //            Console.WriteLine($"MontantTotal : {s.MontantTotal} (attendu: 0)");
            //            Console.WriteLine($"MinutesRestantes : {s.MinutesRestantes} (attendu: 0)");
            //            Console.WriteLine($"Cycle : {s.Cycle} (attendu: BlancsCouleurs)");
            //            Console.WriteLine($"Temperature : {s.Temperature} (attendu: 75)");
            //            Console.WriteLine($"EstEnMarche : {s.EstEnMarche} (attendu: False)\n");
        }
    }
}
