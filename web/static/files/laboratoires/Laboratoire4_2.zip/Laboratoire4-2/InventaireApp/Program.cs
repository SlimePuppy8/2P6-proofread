﻿using System;
using System.Collections.Generic;
using System.IO;


namespace InventaireApp
{
    internal class Program
    {
        const string FICHIER_INVENTAIRE = "../../inventaire.csv";
        const string FICHIER_CRITIQUE = "../../produits_critiques.csv";

        static void Main()
        {

                

            List<Produit> inventaire = new List<Produit>();
            bool quitter = false;

            while (!quitter)
            {
                Console.WriteLine("\n===== MENU INVENTAIRE =====");
                Console.WriteLine("1. Charger inventaire");
                Console.WriteLine("2. Afficher inventaire");
                Console.WriteLine("3. Afficher produits critiques");               
                Console.WriteLine("4. Afficher par catégorie");
                Console.WriteLine("5. Sauvegarder produits critiques");
                Console.WriteLine("6. Quitter et sauvegarder");
                Console.Write("Choix : ");

                string choix = Console.ReadLine();

                switch (choix)
                {
                    case "1":
                       
                        break;

                    case "2":
                       
                        break;

                    case "3":
                       
                        break;                   

                    case "4":
                       

                        break;

                    case "5":
                       
                        break;

                    case "6":
                       
                        quitter = true;
                       
                        break;

                    default:
                       
                        break;
                }
                if (choix != "6")
                {
                    Console.ReadKey();
                    Console.Clear();
                }
            }
        }

        
    }
}
