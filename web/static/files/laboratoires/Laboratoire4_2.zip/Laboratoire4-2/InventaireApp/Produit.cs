﻿using System;

namespace InventaireApp
{
    /// <summary>
    /// Représente les différentes catégories possibles d’un produit.
    /// </summary>
    public enum Categorie
    {
        /// <summary>
        /// Produit alimentaire (nourriture, boisson, etc.).
        /// </summary>
        ALIMENTAIRE,

        /// <summary>
        /// Produit électronique (appareil, accessoire, etc.).
        /// </summary>
        ELECTRONIQUE,

        /// <summary>
        /// Article vestimentaire.
        /// </summary>
        VETEMENT
    }

    /// <summary>
    /// Représente un produit dans un inventaire.
    /// 
    /// La classe permet :
    /// - De stocker les informations d’un produit
    /// - De vérifier si le stock est critique
    /// - De calculer la valeur totale du stock
    /// - De générer des chaînes pour affichage ou sauvegarde
    /// </summary>
    public class Produit
    {
        /// <summary>
        /// Seuil minimal de quantité avant qu’un produit soit considéré en stock critique.
        /// </summary>
        public const int SEUIL_MINIMAL = 10;

        /// <summary>
        /// Nom du produit.
        /// </summary>
        private string Nom { get; set; }

        /// <summary>
        /// Prix unitaire du produit.
        /// </summary>
        private double Prix { get; set; }

        /// <summary>
        /// Quantité disponible en stock.
        /// </summary>
        private int Quantite { get; set; }

        /// <summary>
        /// Catégorie du produit (Alimentaire, Electronique ou Vêtement).
        /// </summary>
        public Categorie Categorie { get; set; }

        /// <summary>
        /// Indique si le produit est en stock critique.
        /// Retourne true si la quantité est inférieure au seuil minimal.
        /// </summary>
        public bool StockCritique
        {
            get { return Quantite < SEUIL_MINIMAL; }
        }

        /// <summary>
        /// Initialise un produit à partir d’une ligne CSV.
        /// 
        /// Format attendu :
        /// Nom;Prix;Quantite;Categorie
        /// 
        /// Exemple :
        /// Lait;2.5;8;ALIMENTAIRE
        /// </summary>
        /// <param name="ligne">
        /// Chaîne contenant les informations du produit séparées par des points-virgules.
        /// </param>
        public Produit(string ligne)
        {
            string[] tab = ligne.Split(';');

            Nom = tab[0];
            Prix = double.Parse(tab[1]);
            Quantite = int.Parse(tab[2]);

            // Catégorie par défaut
            Categorie = Categorie.ALIMENTAIRE;

            // Tentative de conversion de la catégorie
            if (Enum.TryParse(tab[3], true, out Categorie categorie))
                Categorie = categorie;
        }

        /// <summary>
        /// Calcule la valeur totale du stock pour ce produit.
        /// </summary>
        /// <returns>
        /// Le résultat du calcul : Prix × Quantite.
        /// </returns>
        public double ValeurStock()
        {
            return Prix * Quantite;
        }

        /// <summary>
        /// Retourne une chaîne formatée décrivant l’état du produit.
        /// 
        /// Indique si le stock est critique ou non.
        /// </summary>
        /// <returns>
        /// Chaîne descriptive prête à être affichée à l’écran.
        /// </returns>
        public string Etat()
        {
            string etat = StockCritique ? "⚠ STOCK CRITIQUE" : "Stock OK";

            return $"{Nom} | {Prix:C} | Qté: {Quantite} | {Categorie} | {etat}";
        }

        /// <summary>
        /// Retourne les informations du produit au format CSV.
        /// 
        /// Format :
        /// Nom;Prix;Quantite;Categorie
        /// </summary>
        /// <returns>
        /// Chaîne prête à être enregistrée dans un fichier.
        /// </returns>
        public string Info()
        {
            return $"{Nom};{Prix};{Quantite};{Categorie}";
        }
    }
}
