﻿using System;
using MetoApp;

namespace MetoApp
{
    class Program
    {
        static void Main()
        {
            //        Console.WriteLine("===== TEST 1 : Constructeur par défaut =====");
            //        HistoriqueMeteo h1 = new HistoriqueMeteo();
            //        Console.WriteLine("Region attendue : Inconnu");
            //        Console.WriteLine("Region réelle  : " + h1.Region);
            //        Console.WriteLine();

            //        Console.WriteLine("===== TEST 2 : Constructeur avec région valide =====");
            //        HistoriqueMeteo h2 = new HistoriqueMeteo("Paris");
            //        Console.WriteLine("Region attendue : Paris");
            //        Console.WriteLine("Region réelle  : " + h2.Region);
            //        Console.WriteLine();

            //        Console.WriteLine("===== TEST 3 : Constructeur avec région invalide =====");
            //        HistoriqueMeteo h3 = new HistoriqueMeteo("AB");
            //        Console.WriteLine("Region attendue : Inconnu");
            //        Console.WriteLine("Region réelle  : " + h3.Region);
            //        Console.WriteLine();

            //        Console.WriteLine("===== TEST 4 : Ajouter températures =====");
            //        h2.AjouterTemperature(10);
            //        h2.AjouterTemperature(20);
            //        h2.AjouterTemperature(30);

            //        Console.WriteLine("Historique attendu : 10 20 30");
            //        Console.WriteLine(h2.Historique());
            //        Console.WriteLine();

            //        Console.WriteLine("===== TEST 5 : Moyenne / Min / Max =====");
            //        Console.WriteLine("Moyenne attendue : 20");
            //        Console.WriteLine("Moyenne réelle  : " + h2.Moyenne);

            //        Console.WriteLine("Minimum attendu : 10");
            //        Console.WriteLine("Minimum réel    : " + h2.Minimum);

            //        Console.WriteLine("Maximum attendu : 30");
            //        Console.WriteLine("Maximum réel    : " + h2.Maximum);
            //        Console.WriteLine();

            //        Console.WriteLine("===== TEST 6 : Limite NB_MESURES_MAX =====");
            //        for (int i = 1; i <= 10; i++)
            //        {
            //            h1.AjouterTemperature(i);
            //        }

            //        Console.WriteLine("Nombre max attendu : " + HistoriqueMeteo.NB_MESURES_MAX);
            //        Console.WriteLine("Nombre réel        : " + h1.Temperatures.Count);
            //        Console.WriteLine("Historique réel    : " + h1.Historique());
            //        Console.WriteLine();

            //        Console.WriteLine("===== TEST 7 : CompterAuDessus =====");
            //        int nb = h2.CompterAuDessus(15);
            //        Console.WriteLine("Valeur attendue : 2");
            //        Console.WriteLine("Valeur réelle   : " + nb);
            //        Console.WriteLine();

            //        Console.WriteLine("===== TEST 8 : Clone =====");
            //        HistoriqueMeteo copie = h2.Clone();
            //        copie.AjouterTemperature(100);

            //        Console.WriteLine("Original ne doit PAS contenir 100");
            //        Console.WriteLine("Original : " + h2.Historique());
            //        Console.WriteLine("Copie    : " + copie.Historique());
            //        Console.WriteLine();

            //        Console.WriteLine("===== TEST 9 : ComparaisonMoyenne =====");
            //        HistoriqueMeteo h4 = new HistoriqueMeteo("Lyon");
            //        h4.AjouterTemperature(5);
            //        h4.AjouterTemperature(5);
            //        h4.AjouterTemperature(5);

            //        int comparaison = h2.ComparaisonMoyenne(h4);
            //        Console.WriteLine("Résultat attendu : 1 (h2 > h4)");
            //        Console.WriteLine("Résultat réel    : " + comparaison);
            //        Console.WriteLine();

            //        Console.WriteLine("===== FIN DES TESTS =====");
        }
    }
}
