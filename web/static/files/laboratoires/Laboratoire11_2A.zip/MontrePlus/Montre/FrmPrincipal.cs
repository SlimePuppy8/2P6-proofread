﻿using System.Windows.Forms;

namespace ApplicationMontre
{
	public partial class FrmPrincipal : Form
	{
		public const string APP_INFO = "(Matériel)";

		/// <summary>
		///  TODO 01 : En vous référant au diagramme de classe de cet exercice, ajouter la classe MontrePlus
		///  TODO 02 : Compléter le code des constructeurs
		///  TODO 03 : Compléter le code de la méthode ToString() de la classe MontrePlus
		/// </summary>

		private Montre m_objMontre; 
		//==================================
		public FrmPrincipal()
		{
			InitializeComponent();
			Text += APP_INFO;

			m_objMontre = new Montre(9, 15, 42);
			txtAffichageMontre.Text = m_objMontre.ToString();
		}

		//============================================================================
		private void btnAvancer_Click(object sender, System.EventArgs e)
		{
			m_objMontre.AvancerUneSeconde();
			txtAffichageMontre.Text = m_objMontre.ToString();
		}

		//============================================================================
		private void btnDemarrerArreterHorloge_Click(object sender, System.EventArgs e)
		{
			tmrHorloge.Enabled = !tmrHorloge.Enabled;
		}

		//============================================================================
		private void btnInitialiserMontre_Click(object sender, System.EventArgs e)
		{
			m_objMontre = new Montre(23, 59, 55);
			chkMode24Heures.Checked = true;
			txtAffichageMontre.Text = m_objMontre.ToString();
		}
		//============================================================================
		private void mnuFichierQuitter_Click(object sender, System.EventArgs e)
		{
			Close();
		}
		//============================================================================
		private void ChkMode24Heures_CheckedChanged(object sender, System.EventArgs e)
		{
            // TODO 04 : Modifier le type l'objet montre pour utiliser la classe MontrePlus
            // TODO 05 : Modifier le mode d'affichage de l'objet de la classe MontrePlus

            // À COMPLÉTER...
        }
	}
}
