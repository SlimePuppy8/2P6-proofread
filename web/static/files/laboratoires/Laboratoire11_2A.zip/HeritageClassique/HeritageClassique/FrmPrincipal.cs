﻿using System;
using System.Windows.Forms;

namespace HeritageClassique
{
    // TODO 01 : Vous devez définir 3 classes. La classe Personne avec uniquement un nom et une date de naissance,
    // la classe Etudiant qui devra hériter de la classe Personne et ajouter une propriété Matricule. Finalement
    // définir la classe Employe qui devra également hériter de la classe Personne et ajouter la propriété 
    // salaire.
    //
    // TODO 02 : Enlever les commentaires ci-dessous et faire fonctionner le code
    //
    // TODO 03 : Ajouter des méthodes ToString() dans chacune de vos classes afin de ne pas répéter le code.
    //
    public partial class FrmPrincipal : Form
    {
        public FrmPrincipal()
        {
            InitializeComponent();
        }

        private void BtnAfficherInfosPersonne_Click(object sender, EventArgs e)
        {
            //Personne unePersonne = new Personne("Jean Lapointe", new DateTime(1950, 3, 6));

            //string premièreLigne = "Nom : " + unePersonne.Nom + "\n";
            //string deuxièmeLigne = "Date de naissance : " + unePersonne.DateDeNaissance.ToString("le d MMMM yyyy");
            //MessageBox.Show(premièreLigne + deuxièmeLigne);
        }

        private void BtnAfficherInfosEtudiant_Click(object sender, EventArgs e)
        {
            //Etudiant objEtudiant = new Etudiant("Louise Tremblay", new DateTime(1997, 7, 22),15464332);

            //string premièreLigne = "Nom : " + objEtudiant.Nom + "\n";
            //string deuxièmeLigne = "Date de naissance : " + objEtudiant.DateDeNaissance.ToString("le d MMMM yyyy") + "\n";
            //string troisièmeLigne = "Matricule : " + objEtudiant.Matricule;
            //MessageBox.Show(premièreLigne + deuxièmeLigne + troisièmeLigne);
        }

        private void BtnAfficherInfosEmployé_Click(object sender, EventArgs e)
        {
            //Employe objEmployé = new Employe("Germain Houde", new DateTime(1976, 1, 17), 55400);

            //string premièreLigne = "Nom : " + objEmployé.Nom + "\n";
            //string deuxièmeLigne = "Date de naissance : " + objEmployé.DateDeNaissance.ToString("le d MMMM yyyy") + "\n";
            //string troisièmeLigne = "Salaire : " + objEmployé.Salaire.ToString("C0");
            //MessageBox.Show(premièreLigne + deuxièmeLigne + troisièmeLigne);
        }
    }
}

