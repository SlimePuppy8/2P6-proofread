﻿namespace Exercice2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Animal[] animaux =
            //{
            //    new Animal("Ghost", (Animal.TypeAnimal)99),
            //    new Animal("Mia", Animal.TypeAnimal.Chat),
            //    new Animal("Snoopy", Animal.TypeAnimal.Chien),
            //    new Animal("Simba", Animal.TypeAnimal.Lion),
            //    new Animal("Gary", Animal.TypeAnimal.Serpent)
            //};

        }    
    }
}
