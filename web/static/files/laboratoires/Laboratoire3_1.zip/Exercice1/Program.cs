﻿namespace Exercice1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Écriture des trois fichiers csv...");
            List<string[]> texteDepart = new List<string[]>()
            {
                new string[3] {"Prénom", "Nom", "Note" },
                new string[3] {"Jamil", "Gammoudi", "95" },
                new string[3] {"David", "Gagné-Leroux", "90" },
                new string[3] {"Jimmy", "Beaubien", "88" },
                new string[3] {"Philippe", "Martel", "32" },
            };
        }
    }
}
