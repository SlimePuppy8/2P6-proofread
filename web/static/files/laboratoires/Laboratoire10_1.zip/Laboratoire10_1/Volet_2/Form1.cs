using Modeles;
using System.Globalization;

namespace Volet_2_3
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // � COMPL�TER...
        }
        private void cboEtoiles_SelectedIndexChanged(object sender, EventArgs e)
        {
            // � COMPL�TER...
        }

        private void lstPlanetes_SelectedIndexChanged(object sender, EventArgs e)
        {
            // � COMPL�TER...
        }

        private void btnAjouterPlanete_Click(object sender, EventArgs e)
        {
            // � COMPL�TER...
        }

        private void btnAjouterSatellite_Click(object sender, EventArgs e)
        {
            // � COMPL�TER...
        }
    }
}
