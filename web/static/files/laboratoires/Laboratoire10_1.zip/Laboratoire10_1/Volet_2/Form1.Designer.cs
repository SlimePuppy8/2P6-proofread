﻿namespace Volet_2_3
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tableLayoutPrincipal = new TableLayoutPanel();
            pnlSelectionEtoile = new Panel();
            lblEtoiles = new Label();
            cboEtoiles = new ComboBox();
            grpNavigation = new GroupBox();
            tableLayoutNavigation = new TableLayoutPanel();
            lblPlanetes = new Label();
            lblSatellites = new Label();
            lstPlanetes = new ListBox();
            lstSatellites = new ListBox();
            grpAjouterPlanete = new GroupBox();
            tableLayoutAjoutPlanete = new TableLayoutPanel();
            label1 = new Label();
            lblNomPlanete = new Label();
            txtNomPlanete = new TextBox();
            lblMassePlanete = new Label();
            txtMassePlanete = new TextBox();
            btnAjouterPlanete = new Button();
            cboTypePlanete = new ComboBox();
            grpAjouterSatellite = new GroupBox();
            tableLayoutAjoutSatellite = new TableLayoutPanel();
            lblNomSatellite = new Label();
            txtNomSatellite = new TextBox();
            lblMasseSatellite = new Label();
            txtMasseSatellite = new TextBox();
            btnAjouterSatellite = new Button();
            tableLayoutPrincipal.SuspendLayout();
            pnlSelectionEtoile.SuspendLayout();
            grpNavigation.SuspendLayout();
            tableLayoutNavigation.SuspendLayout();
            grpAjouterPlanete.SuspendLayout();
            tableLayoutAjoutPlanete.SuspendLayout();
            grpAjouterSatellite.SuspendLayout();
            tableLayoutAjoutSatellite.SuspendLayout();
            SuspendLayout();
            // 
            // tableLayoutPrincipal
            // 
            tableLayoutPrincipal.ColumnCount = 2;
            tableLayoutPrincipal.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPrincipal.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPrincipal.Controls.Add(pnlSelectionEtoile, 0, 0);
            tableLayoutPrincipal.Controls.Add(grpNavigation, 0, 1);
            tableLayoutPrincipal.Controls.Add(grpAjouterPlanete, 0, 2);
            tableLayoutPrincipal.Controls.Add(grpAjouterSatellite, 1, 2);
            tableLayoutPrincipal.Dock = DockStyle.Fill;
            tableLayoutPrincipal.Location = new Point(10, 10);
            tableLayoutPrincipal.Name = "tableLayoutPrincipal";
            tableLayoutPrincipal.RowCount = 3;
            tableLayoutPrincipal.RowStyles.Add(new RowStyle(SizeType.Absolute, 60F));
            tableLayoutPrincipal.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPrincipal.RowStyles.Add(new RowStyle(SizeType.Absolute, 180F));
            tableLayoutPrincipal.Size = new Size(964, 541);
            tableLayoutPrincipal.TabIndex = 0;
            // 
            // pnlSelectionEtoile
            // 
            tableLayoutPrincipal.SetColumnSpan(pnlSelectionEtoile, 2);
            pnlSelectionEtoile.Controls.Add(lblEtoiles);
            pnlSelectionEtoile.Controls.Add(cboEtoiles);
            pnlSelectionEtoile.Dock = DockStyle.Fill;
            pnlSelectionEtoile.Location = new Point(3, 3);
            pnlSelectionEtoile.Name = "pnlSelectionEtoile";
            pnlSelectionEtoile.Size = new Size(958, 54);
            pnlSelectionEtoile.TabIndex = 0;
            // 
            // lblEtoiles
            // 
            lblEtoiles.AutoSize = true;
            lblEtoiles.Location = new Point(12, 18);
            lblEtoiles.Name = "lblEtoiles";
            lblEtoiles.Size = new Size(42, 15);
            lblEtoiles.TabIndex = 0;
            lblEtoiles.Text = "Étoile :";
            // 
            // cboEtoiles
            // 
            cboEtoiles.DropDownStyle = ComboBoxStyle.DropDownList;
            cboEtoiles.FormattingEnabled = true;
            cboEtoiles.Location = new Point(70, 14);
            cboEtoiles.Name = "cboEtoiles";
            cboEtoiles.Size = new Size(250, 23);
            cboEtoiles.TabIndex = 1;
            cboEtoiles.SelectedIndexChanged += cboEtoiles_SelectedIndexChanged;
            // 
            // grpNavigation
            // 
            tableLayoutPrincipal.SetColumnSpan(grpNavigation, 2);
            grpNavigation.Controls.Add(tableLayoutNavigation);
            grpNavigation.Dock = DockStyle.Fill;
            grpNavigation.Location = new Point(3, 63);
            grpNavigation.Name = "grpNavigation";
            grpNavigation.Padding = new Padding(10);
            grpNavigation.Size = new Size(958, 295);
            grpNavigation.TabIndex = 1;
            grpNavigation.TabStop = false;
            grpNavigation.Text = "Navigation";
            // 
            // tableLayoutNavigation
            // 
            tableLayoutNavigation.ColumnCount = 2;
            tableLayoutNavigation.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutNavigation.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutNavigation.Controls.Add(lblPlanetes, 0, 0);
            tableLayoutNavigation.Controls.Add(lblSatellites, 1, 0);
            tableLayoutNavigation.Controls.Add(lstPlanetes, 0, 1);
            tableLayoutNavigation.Controls.Add(lstSatellites, 1, 1);
            tableLayoutNavigation.Dock = DockStyle.Fill;
            tableLayoutNavigation.Location = new Point(10, 26);
            tableLayoutNavigation.Name = "tableLayoutNavigation";
            tableLayoutNavigation.RowCount = 2;
            tableLayoutNavigation.RowStyles.Add(new RowStyle(SizeType.Absolute, 30F));
            tableLayoutNavigation.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutNavigation.Size = new Size(938, 259);
            tableLayoutNavigation.TabIndex = 0;
            // 
            // lblPlanetes
            // 
            lblPlanetes.Anchor = AnchorStyles.Left;
            lblPlanetes.AutoSize = true;
            lblPlanetes.Location = new Point(3, 7);
            lblPlanetes.Name = "lblPlanetes";
            lblPlanetes.Size = new Size(51, 15);
            lblPlanetes.TabIndex = 0;
            lblPlanetes.Text = "Planètes";
            // 
            // lblSatellites
            // 
            lblSatellites.Anchor = AnchorStyles.Left;
            lblSatellites.AutoSize = true;
            lblSatellites.Location = new Point(472, 7);
            lblSatellites.Name = "lblSatellites";
            lblSatellites.Size = new Size(53, 15);
            lblSatellites.TabIndex = 1;
            lblSatellites.Text = "Satellites";
            // 
            // lstPlanetes
            // 
            lstPlanetes.Dock = DockStyle.Fill;
            lstPlanetes.FormattingEnabled = true;
            lstPlanetes.IntegralHeight = false;
            lstPlanetes.ItemHeight = 15;
            lstPlanetes.Location = new Point(3, 33);
            lstPlanetes.Name = "lstPlanetes";
            lstPlanetes.Size = new Size(463, 223);
            lstPlanetes.TabIndex = 2;
            lstPlanetes.SelectedIndexChanged += lstPlanetes_SelectedIndexChanged;
            // 
            // lstSatellites
            // 
            lstSatellites.Dock = DockStyle.Fill;
            lstSatellites.FormattingEnabled = true;
            lstSatellites.IntegralHeight = false;
            lstSatellites.ItemHeight = 15;
            lstSatellites.Location = new Point(472, 33);
            lstSatellites.Name = "lstSatellites";
            lstSatellites.Size = new Size(463, 223);
            lstSatellites.TabIndex = 3;
            // 
            // grpAjouterPlanete
            // 
            grpAjouterPlanete.Controls.Add(tableLayoutAjoutPlanete);
            grpAjouterPlanete.Dock = DockStyle.Fill;
            grpAjouterPlanete.Location = new Point(3, 364);
            grpAjouterPlanete.Name = "grpAjouterPlanete";
            grpAjouterPlanete.Padding = new Padding(10);
            grpAjouterPlanete.Size = new Size(476, 174);
            grpAjouterPlanete.TabIndex = 2;
            grpAjouterPlanete.TabStop = false;
            grpAjouterPlanete.Text = "Ajouter une planète";
            // 
            // tableLayoutAjoutPlanete
            // 
            tableLayoutAjoutPlanete.ColumnCount = 2;
            tableLayoutAjoutPlanete.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 80F));
            tableLayoutAjoutPlanete.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutAjoutPlanete.Controls.Add(label1, 0, 2);
            tableLayoutAjoutPlanete.Controls.Add(lblNomPlanete, 0, 0);
            tableLayoutAjoutPlanete.Controls.Add(txtNomPlanete, 1, 0);
            tableLayoutAjoutPlanete.Controls.Add(lblMassePlanete, 0, 1);
            tableLayoutAjoutPlanete.Controls.Add(txtMassePlanete, 1, 1);
            tableLayoutAjoutPlanete.Controls.Add(btnAjouterPlanete, 1, 3);
            tableLayoutAjoutPlanete.Controls.Add(cboTypePlanete, 1, 2);
            tableLayoutAjoutPlanete.Dock = DockStyle.Fill;
            tableLayoutAjoutPlanete.Location = new Point(10, 26);
            tableLayoutAjoutPlanete.Name = "tableLayoutAjoutPlanete";
            tableLayoutAjoutPlanete.RowCount = 4;
            tableLayoutAjoutPlanete.RowStyles.Add(new RowStyle(SizeType.Absolute, 35F));
            tableLayoutAjoutPlanete.RowStyles.Add(new RowStyle(SizeType.Absolute, 35F));
            tableLayoutAjoutPlanete.RowStyles.Add(new RowStyle(SizeType.Absolute, 26F));
            tableLayoutAjoutPlanete.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutAjoutPlanete.Size = new Size(456, 138);
            tableLayoutAjoutPlanete.TabIndex = 0;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.Left;
            label1.AutoSize = true;
            label1.Location = new Point(3, 75);
            label1.Name = "label1";
            label1.Size = new Size(38, 15);
            label1.TabIndex = 6;
            label1.Text = "Type :";
            // 
            // lblNomPlanete
            // 
            lblNomPlanete.Anchor = AnchorStyles.Left;
            lblNomPlanete.AutoSize = true;
            lblNomPlanete.Location = new Point(3, 10);
            lblNomPlanete.Name = "lblNomPlanete";
            lblNomPlanete.Size = new Size(40, 15);
            lblNomPlanete.TabIndex = 0;
            lblNomPlanete.Text = "Nom :";
            // 
            // txtNomPlanete
            // 
            txtNomPlanete.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            txtNomPlanete.Location = new Point(83, 6);
            txtNomPlanete.Name = "txtNomPlanete";
            txtNomPlanete.Size = new Size(370, 23);
            txtNomPlanete.TabIndex = 1;
            // 
            // lblMassePlanete
            // 
            lblMassePlanete.Anchor = AnchorStyles.Left;
            lblMassePlanete.AutoSize = true;
            lblMassePlanete.Location = new Point(3, 45);
            lblMassePlanete.Name = "lblMassePlanete";
            lblMassePlanete.Size = new Size(46, 15);
            lblMassePlanete.TabIndex = 2;
            lblMassePlanete.Text = "Masse :";
            // 
            // txtMassePlanete
            // 
            txtMassePlanete.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            txtMassePlanete.Location = new Point(83, 41);
            txtMassePlanete.Name = "txtMassePlanete";
            txtMassePlanete.Size = new Size(370, 23);
            txtMassePlanete.TabIndex = 3;
            // 
            // btnAjouterPlanete
            // 
            btnAjouterPlanete.Anchor = AnchorStyles.Left;
            btnAjouterPlanete.AutoSize = true;
            btnAjouterPlanete.Location = new Point(83, 102);
            btnAjouterPlanete.Name = "btnAjouterPlanete";
            btnAjouterPlanete.Size = new Size(136, 29);
            btnAjouterPlanete.TabIndex = 4;
            btnAjouterPlanete.Text = "Ajouter";
            btnAjouterPlanete.UseVisualStyleBackColor = true;
            btnAjouterPlanete.Click += btnAjouterPlanete_Click;
            // 
            // cboTypePlanete
            // 
            cboTypePlanete.DropDownStyle = ComboBoxStyle.DropDownList;
            cboTypePlanete.FormattingEnabled = true;
            cboTypePlanete.Location = new Point(83, 73);
            cboTypePlanete.Name = "cboTypePlanete";
            cboTypePlanete.Size = new Size(233, 23);
            cboTypePlanete.TabIndex = 5;
            // 
            // grpAjouterSatellite
            // 
            grpAjouterSatellite.Controls.Add(tableLayoutAjoutSatellite);
            grpAjouterSatellite.Dock = DockStyle.Fill;
            grpAjouterSatellite.Location = new Point(485, 364);
            grpAjouterSatellite.Name = "grpAjouterSatellite";
            grpAjouterSatellite.Padding = new Padding(10);
            grpAjouterSatellite.Size = new Size(476, 174);
            grpAjouterSatellite.TabIndex = 3;
            grpAjouterSatellite.TabStop = false;
            grpAjouterSatellite.Text = "Ajouter un satellite";
            // 
            // tableLayoutAjoutSatellite
            // 
            tableLayoutAjoutSatellite.ColumnCount = 2;
            tableLayoutAjoutSatellite.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 80F));
            tableLayoutAjoutSatellite.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutAjoutSatellite.Controls.Add(lblNomSatellite, 0, 0);
            tableLayoutAjoutSatellite.Controls.Add(txtNomSatellite, 1, 0);
            tableLayoutAjoutSatellite.Controls.Add(lblMasseSatellite, 0, 1);
            tableLayoutAjoutSatellite.Controls.Add(txtMasseSatellite, 1, 1);
            tableLayoutAjoutSatellite.Controls.Add(btnAjouterSatellite, 1, 2);
            tableLayoutAjoutSatellite.Dock = DockStyle.Fill;
            tableLayoutAjoutSatellite.Location = new Point(10, 26);
            tableLayoutAjoutSatellite.Name = "tableLayoutAjoutSatellite";
            tableLayoutAjoutSatellite.RowCount = 4;
            tableLayoutAjoutSatellite.RowStyles.Add(new RowStyle(SizeType.Absolute, 35F));
            tableLayoutAjoutSatellite.RowStyles.Add(new RowStyle(SizeType.Absolute, 35F));
            tableLayoutAjoutSatellite.RowStyles.Add(new RowStyle(SizeType.Absolute, 40F));
            tableLayoutAjoutSatellite.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutAjoutSatellite.Size = new Size(456, 138);
            tableLayoutAjoutSatellite.TabIndex = 0;
            // 
            // lblNomSatellite
            // 
            lblNomSatellite.Anchor = AnchorStyles.Left;
            lblNomSatellite.AutoSize = true;
            lblNomSatellite.Location = new Point(3, 10);
            lblNomSatellite.Name = "lblNomSatellite";
            lblNomSatellite.Size = new Size(40, 15);
            lblNomSatellite.TabIndex = 0;
            lblNomSatellite.Text = "Nom :";
            // 
            // txtNomSatellite
            // 
            txtNomSatellite.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            txtNomSatellite.Location = new Point(83, 6);
            txtNomSatellite.Name = "txtNomSatellite";
            txtNomSatellite.Size = new Size(370, 23);
            txtNomSatellite.TabIndex = 1;
            // 
            // lblMasseSatellite
            // 
            lblMasseSatellite.Anchor = AnchorStyles.Left;
            lblMasseSatellite.AutoSize = true;
            lblMasseSatellite.Location = new Point(3, 45);
            lblMasseSatellite.Name = "lblMasseSatellite";
            lblMasseSatellite.Size = new Size(46, 15);
            lblMasseSatellite.TabIndex = 2;
            lblMasseSatellite.Text = "Masse :";
            // 
            // txtMasseSatellite
            // 
            txtMasseSatellite.Anchor = AnchorStyles.Left | AnchorStyles.Right;
            txtMasseSatellite.Location = new Point(83, 41);
            txtMasseSatellite.Name = "txtMasseSatellite";
            txtMasseSatellite.Size = new Size(370, 23);
            txtMasseSatellite.TabIndex = 3;
            // 
            // btnAjouterSatellite
            // 
            btnAjouterSatellite.Anchor = AnchorStyles.Left;
            btnAjouterSatellite.AutoSize = true;
            btnAjouterSatellite.Location = new Point(83, 75);
            btnAjouterSatellite.Name = "btnAjouterSatellite";
            btnAjouterSatellite.Size = new Size(108, 30);
            btnAjouterSatellite.TabIndex = 4;
            btnAjouterSatellite.Text = "Ajouter";
            btnAjouterSatellite.UseVisualStyleBackColor = true;
            btnAjouterSatellite.Click += btnAjouterSatellite_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(984, 561);
            Controls.Add(tableLayoutPrincipal);
            MinimumSize = new Size(900, 598);
            Name = "Form1";
            Padding = new Padding(10);
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Système stellaire";
            Load += Form1_Load;
            tableLayoutPrincipal.ResumeLayout(false);
            pnlSelectionEtoile.ResumeLayout(false);
            pnlSelectionEtoile.PerformLayout();
            grpNavigation.ResumeLayout(false);
            tableLayoutNavigation.ResumeLayout(false);
            tableLayoutNavigation.PerformLayout();
            grpAjouterPlanete.ResumeLayout(false);
            tableLayoutAjoutPlanete.ResumeLayout(false);
            tableLayoutAjoutPlanete.PerformLayout();
            grpAjouterSatellite.ResumeLayout(false);
            tableLayoutAjoutSatellite.ResumeLayout(false);
            tableLayoutAjoutSatellite.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPrincipal;
        private System.Windows.Forms.Panel pnlSelectionEtoile;
        private System.Windows.Forms.Label lblEtoiles;
        private System.Windows.Forms.ComboBox cboEtoiles;
        private System.Windows.Forms.GroupBox grpNavigation;
        private System.Windows.Forms.TableLayoutPanel tableLayoutNavigation;
        private System.Windows.Forms.Label lblPlanetes;
        private System.Windows.Forms.Label lblSatellites;
        private System.Windows.Forms.ListBox lstPlanetes;
        private System.Windows.Forms.ListBox lstSatellites;
        private System.Windows.Forms.GroupBox grpAjouterPlanete;
        private System.Windows.Forms.TableLayoutPanel tableLayoutAjoutPlanete;
        private System.Windows.Forms.Label lblNomPlanete;
        private System.Windows.Forms.TextBox txtNomPlanete;
        private System.Windows.Forms.Label lblMassePlanete;
        private System.Windows.Forms.TextBox txtMassePlanete;
        private System.Windows.Forms.Button btnAjouterPlanete;
        private System.Windows.Forms.GroupBox grpAjouterSatellite;
        private System.Windows.Forms.TableLayoutPanel tableLayoutAjoutSatellite;
        private System.Windows.Forms.Label lblNomSatellite;
        private System.Windows.Forms.TextBox txtNomSatellite;
        private System.Windows.Forms.Label lblMasseSatellite;
        private System.Windows.Forms.TextBox txtMasseSatellite;
        private System.Windows.Forms.Button btnAjouterSatellite;
        private Label label1;
        private ComboBox cboTypePlanete;
    }

}
