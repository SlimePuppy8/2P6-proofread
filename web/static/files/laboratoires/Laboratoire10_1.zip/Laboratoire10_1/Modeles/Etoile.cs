﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Modeles
{
    public class Etoile
    {
        public string Nom { get; private set; }
        public List<Planete> Planetes { get; private set; }

        public Etoile(string nom, List<Planete> planetes)
        {
            Nom = nom;
            Planetes = planetes;
        }

        public override string ToString()
        {
            return Nom;
        }

    }
}
