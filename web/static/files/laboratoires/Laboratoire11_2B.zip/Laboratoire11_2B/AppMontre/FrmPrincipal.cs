namespace AppMontre
{
    public partial class FrmPrincipal : Form
    {
        // TODO 01 : Dans le projet `AppMontre`, choisir l'option "Ajouter une classe et nommer le nouveau fichier "Montre.cs"

        // TODO 02 : La premi�re fois que nous avons construit la classe Montre nous avons utilis� un diagramme de classe (Labo 2.1).
        // Dans ce projet il y a une interface nomm�e IMontre, elle contient les propri�t�s et m�thodes que la montre devra impl�menter.


        // TODO 03 : Ajouter deux constructeurs � la classe Montre (impossible d'imposer les constructeurs dans une interface)
        // Le constructeur devra avoir 3 param�tres soit : les heures, les minutes et les secondes.

        // TODO 04 : Compl�ter le code la classe Montre


        private IMontre m_objMontre; // Une r�f�rence vers un objet qui impl�mente l'interface IMontre
        //==================================
        public FrmPrincipal()
        {
            InitializeComponent();

            // TODO 05 : Retirer tous les commentaires devant le code jusqu'� la fin et ex�cuter le programme il devrait fonctionner. 

            //m_objMontre = new Montre(9, 15, 42);
            //txtAffichageMontre.Text = m_objMontre.TempsCourant;
        }

        //============================================================================
        // Ev�nement associ� au tick de l'horloge. � chaque tick, on avance d'une seconde.
        private void btnAvancer_Click(object sender, System.EventArgs e)
        {
            //m_objMontre.AvancerUneSeconde();
            //txtAffichageMontre.Text = m_objMontre.TempsCourant;
        }

        //============================================================================
        private void btnDemarrerArreterHorloge_Click(object sender, System.EventArgs e)
        {
            //tmrHorloge.Enabled = !tmrHorloge.Enabled;
        }

        //============================================================================
        private void btnInitialiserMontre_Click(object sender, System.EventArgs e)
        {
            //m_objMontre = new Montre(23, 59, 55);
            //txtAffichageMontre.Text = m_objMontre.TempsCourant;
        }
        //============================================================================
        private void mnuFichierQuitter_Click(object sender, System.EventArgs e)
        {
            Close();
        }
    }
}
