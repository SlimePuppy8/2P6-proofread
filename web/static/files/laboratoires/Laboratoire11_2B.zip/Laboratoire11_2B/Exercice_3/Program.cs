﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercice_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // TODO 1 : À partir des diagrammes de classes, créez l'interface `ILecteurAudio`.

            // TODO 2 : Modifier la déclaration de ``LecteurAudio`` pour qu’elle implémente cette interface.

            // TODO 3 : Testez votre implémentation en instanciant un objet `ILecteurAudio monLecteur` et assurez-vous que l'appel des méthodes Jouer() et Pause() soit fonctionnel.



        }
    }
}
