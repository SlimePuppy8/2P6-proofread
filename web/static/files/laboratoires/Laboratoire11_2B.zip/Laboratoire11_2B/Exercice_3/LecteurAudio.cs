﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercice_3
{
    /// <summary>
    /// Modélise un lecteur audio simple
    /// </summary>
    public class LecteurAudio
    {
        private string m_pisteCourante;
        private bool m_estEnLecture;

        /// <summary>
        /// Piste audio actuellement chargée dans le lecteur
        /// </summary>
        public string PisteCourante
        {
            get { return m_pisteCourante; }
        }

        /// <summary>
        /// Indique si le lecteur est en train de jouer la piste
        /// </summary>
        public bool EstEnLecture
        {
            get { return m_estEnLecture; }
        }

        /// <summary>
        /// Crée un lecteur audio avec une piste initiale
        /// </summary>
        public LecteurAudio(string pisteInitiale)
        {
            m_pisteCourante = pisteInitiale;
            m_estEnLecture = false;
        }

        /// <summary>
        /// Lance la lecture de la piste courante
        /// </summary>
        public void Jouer()
        {
            if (!string.IsNullOrEmpty(m_pisteCourante))
            {
                m_estEnLecture = true;
                Console.WriteLine($"Lecture de : {m_pisteCourante}");
            }
        }

        /// <summary>
        /// Met la lecture en pause
        /// </summary>
        public void Pause()
        {
            if (m_estEnLecture)
            {
                m_estEnLecture = false;
                Console.WriteLine("Lecture en pause");
            }
        }

        /// <summary>
        /// Charge une nouvelle piste dans le lecteur
        /// </summary>
        public void ChargerPiste(string nouvellePiste)
        {
            m_pisteCourante = nouvellePiste;
            Console.WriteLine($"Nouvelle piste chargée : {m_pisteCourante}");
        }
    }
}
