﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercice_1
{

    /// <summary>
    /// Contrat à respecter pour modéliser un thermostat électronique
    /// </summary>
    public interface IThermostat
    {
        /// <summary>
        /// Obtient la température actuelle du thermostat
        /// </summary>
        double Temperature { get;}

        /// <summary>
        /// Augmente la température d'un degré
        /// </summary>
        void AugmenterTemperature();

        /// <summary>
        /// Diminue la température d'un degré
        /// </summary>
        void DiminuerTemperature();
    }
}
