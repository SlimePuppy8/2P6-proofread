﻿namespace Exercice_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // TODO 1 : À partir des diagrammes de classes, créez une classe `Thermostat` qui implémente l'interface `IThermostat`.

            // TODO 2 : Dans votre `Main()`, intanciez un nouvel objet  ``Thermostat unThermostat`` et ``IThermostat unAutreThermostat``.

            // TODO 3 : Est-il possible d'appeler la méthode AugmenterTemperature() à partir des objets `unThermostat` et `unAutreThermostat` ? Si oui, pourquoi est-ce le cas ?

            // TODO 4 : Est-il possible d'appeler la méthode ResetTempérature() à partir des objets `unThermostat` et `unAutreThermostat` ? **Astuce** : vous devrez utiliser le transtypage pour corriger l'erreur obtenu.

        }
    }
}
