﻿using System;

namespace Exercice3
{
    /// ====================================================================================
    /// <summary>
    ///	Énumération de différents breuvages.
    /// </summary>
    /// ------------------------------------------------------------------------------------
    public enum SorteBreuvage { JusOrange, JusRaisin, JusPomme, TheGlace };

    /// ===========================================================================
    /// <summary>
    ///  Modélise une machine distributrice offrant 4 breuvages différents. 
    ///  On peut recharger la machine et obtenir des informations sur les quantités
    ///  de canettes restant dans la machine.
    /// </summary>
    /// ---------------------------------------------------------------------------
    public class Distributrice
    {
        #region CONSTANTE
        /// -------------------------------------------------------------
        /// <summary>
        /// Représente la quantité maximale d'un breuvage
        /// </summary>
        /// -------------------------------------------------------------
        private const int MAX_QUANTITE = 5;
        #endregion

        #region CHAMPS et PROPRIÉTÉS
        /// <summary>
        /// Nombre de "Coke" disponibles dans la machine distributrice
        /// </summary>
        private int m_nbJusOrange;
        /// <summary>
        /// Nombre de "7up" disponibles dans la machine distributrice
        /// </summary>
        private int m_nbJusRaisin;
        /// <summary>
        /// Nombre de "Jus de pommes" disponibles dans la machine distributrice
        /// </summary>
        private int m_nbJusPomme;
        /// <summary>
        /// Nombre de "Thé glacé" disponibles dans la machine distributrice
        /// </summary>
        private int m_nbTheGlace;

        //========================================================================================
        /// <summary>
        ///   Obtient si oui ou non la machine est vide.
        /// </summary>
        /// -------------------------------------------------------------------------------------
        public bool EstVide
        {
            get { return m_nbJusOrange == 0 && m_nbJusRaisin == 0 && m_nbJusPomme == 0 && m_nbTheGlace == 0; }
        }
        #endregion

        #region CONTRUCTEURS
        ///==============================================================
        /// <summary>
        ///  Initialise une nouvelle instance de la classe Machine 
        ///  avec un nombre maximum de canettes pour chacun des breuvages. 
        /// </summary>
        /// --------------------------------------------------------------
        public Distributrice()
        {
            m_nbJusOrange = 0;
            m_nbJusRaisin = 0;
            m_nbJusPomme = 0;
            m_nbTheGlace = 0;
        }
        #endregion

        #region MÉTHODES
        ///====================================================================================
        /// <summary>
        /// Recharge la machine en ré-initialisant les quantités de chaque breuvage au maximum.
        /// </summary>
        /// -----------------------------------------------------------------------------------
        public void Recharger()
        {
            m_nbJusOrange = MAX_QUANTITE;
            m_nbJusRaisin = MAX_QUANTITE;
            m_nbJusPomme = MAX_QUANTITE;
            m_nbTheGlace = MAX_QUANTITE;
        }
        ///======================================================================
        /// <summary>
        ///  Obtient la quantité de cannettes disponible du breuvage spécifié.
        /// </summary>
        /// <param name="pBreuvage">breuvage à vérifier</param>
        /// <returns>quantité de canettes</returns>
        /// ---------------------------------------------------------------------
        public int Quantite(SorteBreuvage pBreuvage)
        {
            switch (pBreuvage)
            {
                case SorteBreuvage.JusOrange:
                    return m_nbJusOrange;
                case SorteBreuvage.JusRaisin:
                    return m_nbJusRaisin;
                case SorteBreuvage.JusPomme:
                    return m_nbJusPomme;
                case SorteBreuvage.TheGlace:
                    return m_nbTheGlace;
                default:
                    return 0;
            }
        }
        //================================================================================
        /// <summary>
        ///  Ejecte le breuvage spécifié , c'est-à-dire décrémente le nombre de canettes
        ///  du breuvage spécifié s'il en reste.
        /// </summary>
        /// <param name="pBreuvage">breuvage à modifier</param>
        /// ------------------------------------------------------------------------------
        public void Ejecter(SorteBreuvage pBreuvage)
        {
            if (!EstDisponible(pBreuvage))
            {
                throw new InvalidOperationException();
            }

            switch (pBreuvage)
            {
                case SorteBreuvage.JusOrange:
                    m_nbJusOrange--;
                    break;
                case SorteBreuvage.JusRaisin:
                    m_nbJusRaisin--;
                    break;
                case SorteBreuvage.JusPomme:
                    m_nbJusPomme--;
                    break;
                case SorteBreuvage.TheGlace:
                    m_nbTheGlace--;
                    break;
            }
        }
        //=======================================================
        /// <summary>
        ///  Obtient si oui ou non s'il reste du breuvage spécifié
        /// </summary>
        /// <param name="pBreuvage">breuvage à vérifier</param>
        /// <returns>disponible ou non </returns>
        /// -----------------------------------------------------
        public bool EstDisponible(SorteBreuvage pBreuvage)
        {
            return Quantite(pBreuvage) > 0;
        }
    }
    #endregion
}
