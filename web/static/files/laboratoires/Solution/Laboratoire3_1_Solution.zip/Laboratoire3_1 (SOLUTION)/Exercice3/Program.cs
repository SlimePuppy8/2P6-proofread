﻿namespace Exercice3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            bool quitter = false;

            Distributrice distributrice = new Distributrice();

            while(!quitter)
            {
                Console.Clear();
                Console.WriteLine("==============================");
                Console.Write("La distributrice");
                if (distributrice.EstVide)
                {
                    Console.WriteLine(" est vide.");
                }
                else
                {
                    Console.WriteLine();
                }
                Console.WriteLine();
                Console.WriteLine($"Jus d'orange: \t{distributrice.Quantite(SorteBreuvage.JusOrange)}");
                Console.WriteLine($"Jus de raisin: \t{distributrice.Quantite(SorteBreuvage.JusRaisin)}");
                Console.WriteLine($"Jus de pomme: \t{distributrice.Quantite(SorteBreuvage.JusPomme)}");
                Console.WriteLine($"Thé glacé: \t{distributrice.Quantite(SorteBreuvage.TheGlace)}");
                Console.WriteLine("==============================");
                Console.WriteLine();
                Console.WriteLine();


                Console.WriteLine("--- Menu ---");
                Console.WriteLine("1 - Consommer un jus d'orange");
                Console.WriteLine("2 - Consommer un jus de raisin");
                Console.WriteLine("3 - Consommer un jus de pomme");
                Console.WriteLine("4 - Consommer un thé glacé");
                Console.WriteLine("5 - Recharger la distributrice");
                Console.WriteLine("Q - Quitter");
                Console.WriteLine();
                Console.Write("Veuillez faire un choix: ");

                string? choix = Console.ReadLine();

                switch (choix)
                {
                    case "1":
                        Consommer(distributrice, SorteBreuvage.JusOrange);
                        break;
                    case "2":
                        Consommer(distributrice, SorteBreuvage.JusRaisin);
                        break;
                    case "3":
                        Consommer(distributrice, SorteBreuvage.JusPomme);
                        break;
                    case "4":
                        Consommer(distributrice, SorteBreuvage.TheGlace);
                        break;
                    case "5":
                        distributrice.Recharger();
                        break;
                    case "q":
                    case "Q":
                        quitter = true;
                        break;
                }
            }
        }

        static void Consommer(Distributrice distributrice, SorteBreuvage sorte)
        {
            if (distributrice.EstDisponible(sorte))
            {
                distributrice.Ejecter(sorte);
            }
            else
            {
                Console.WriteLine();
                Console.WriteLine("Opération impossible, il ne reste plus assez de quantité pour cette sorte.");
                Console.WriteLine("Veuillez appuyer sur entrée pour continuer...");
                Console.ReadLine();
            }
        }
    }
}
