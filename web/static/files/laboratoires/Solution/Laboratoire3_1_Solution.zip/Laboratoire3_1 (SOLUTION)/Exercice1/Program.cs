﻿namespace Exercice1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Écriture des trois fichiers csv...");
            List<string[]> texteDepart = new List<string[]>()
            {
                new string[3] {"Prénom", "Nom", "Note" },
                new string[3] {"Jamil", "Gammoudi", "95" },
                new string[3] {"David", "Gagné-Leroux", "90" },
                new string[3] {"Jimmy", "Beaubien", "88" },
                new string[3] {"Philippe", "Martel", "32" },
            };


            EcriveurFichierCSV ecriveurVirgule = new EcriveurFichierCSV("C:/EspaceLabo", "fichierVirgule.csv", TypeDelimiteur.Virgule);
            EcriveurFichierCSV ecriveurPointVirgule = new EcriveurFichierCSV("C:/EspaceLabo", "fichierPointVirgule.csv", TypeDelimiteur.PointVirgule);
            EcriveurFichierCSV ecriveurLigneVerticale = new EcriveurFichierCSV("C:/EspaceLabo", "fichierLigneVerticale.csv", TypeDelimiteur.LigneVerticale);

            foreach(var ligne in texteDepart)
            {
                ecriveurVirgule.EcrireLigne(ligne);
                ecriveurPointVirgule.EcrireLigne(ligne);
                ecriveurLigneVerticale.EcrireLigne(ligne);
            }


            Console.WriteLine("...terminé avec succès!");
        }
    }
}
