﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercice1
{
    public enum TypeDelimiteur
    {
        Virgule,
        PointVirgule,
        LigneVerticale
    }
    internal class EcriveurFichierCSV
    {
        public string CHEMIN_PAR_DEFAUT = "c:/EspaceLabo";
        public string NOM_FICHIER_DEFAUT = "monFichier.csv";
        

        private string m_cheminAccess = "";
        private string m_nomFichier = "";
        private TypeDelimiteur m_delimiteur = TypeDelimiteur.Virgule;

        public string CheminAcces
        {
            get { return m_cheminAccess; }
            private set
            {
                if (Path.Exists(value))
                {
                    m_cheminAccess = value;
                }
                else
                {
                    m_cheminAccess = CHEMIN_PAR_DEFAUT;
                }
            }
        }
        public string NomFichier
        {
            get { return m_nomFichier; }
            private set
            {
                if (value.Length > 0)
                {
                    m_nomFichier = value;
                }
                else
                {
                    m_nomFichier = NOM_FICHIER_DEFAUT;
                }
            }
        }


        public string Delimiteur
        {
            get 
            {
                string delimiteur = ",";

                switch (m_delimiteur)
                {
                    case TypeDelimiteur.LigneVerticale:
                        delimiteur = "|";
                        break;
                    case TypeDelimiteur.PointVirgule:
                        delimiteur = ";";
                        break;
                    case TypeDelimiteur.Virgule:
                    default:
                        delimiteur = ",";
                        break;
                }

                return delimiteur; 
            }
        }


        public EcriveurFichierCSV(string cheminAcces, string nomFichier, TypeDelimiteur delimiteur) 
        {
            CheminAcces = cheminAcces;
            NomFichier = nomFichier;

            if (delimiteur < TypeDelimiteur.Virgule || delimiteur > TypeDelimiteur.LigneVerticale)
            {
                m_delimiteur = TypeDelimiteur.Virgule;
            }
            m_delimiteur = delimiteur;
        }

        public void EcrireLigne(string[] colonnes)
        {
            using (var writer = new StreamWriter($"{CheminAcces}/{NomFichier}", true))
            {
                int i = 0;
                while (i < colonnes.Length - 1)
                {
                    writer.Write(colonnes[i] + Delimiteur);
                    i++;
                }

                writer.WriteLine(colonnes[i]);
            }
        }
    }
}
