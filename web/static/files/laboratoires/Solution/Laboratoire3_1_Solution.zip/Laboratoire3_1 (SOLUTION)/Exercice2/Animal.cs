﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercice2
{
    public enum TypeAnimal
    {
        Inconnu,
        Chat,
        Chien,
        Lion,
        Serpent
    }
    public class Animal
    {
        

        private string m_nom;
        private TypeAnimal m_type;


        public TypeAnimal Type
        {
            get
            {
                return m_type;
            }
            private set
            {
                if (value < TypeAnimal.Inconnu || value > TypeAnimal.Serpent)
                {
                    m_type = TypeAnimal.Inconnu;
                }
                else
                {
                    m_type = value;
                }
            }
        }

        public string Nom
        {
            get { return m_nom; }
        }

        public string Son
        {
            get
            {
                switch (m_type)
                {
                    case TypeAnimal.Chat:
                        return "Miaou";
                    case TypeAnimal.Chien:
                        return "Wouf";
                    case TypeAnimal.Lion:
                        return "Roar";
                    case TypeAnimal.Serpent:
                        return "Ssss";
                    case TypeAnimal.Inconnu:
                    default:
                        return "????";
                }
            }
        }


        public string Espece
        {
            get
            {
                switch (m_type)
                {
                    case TypeAnimal.Chat:
                        return "chat";
                    case TypeAnimal.Chien:
                        return "chien";
                    case TypeAnimal.Lion:
                        return "lion";
                    case TypeAnimal.Serpent:
                        return "serpent";
                    case TypeAnimal.Inconnu:
                    default:
                        return "????";
                }
            }
        }

        public Animal(string nom, TypeAnimal type)
        {
            m_nom = nom;
            Type = type; 
        }

        public string Parler()
        {
            return $"Le {Espece} {Nom} parle tout doucement: \"{Son}!\"";
        }

        public string Crier()
        {
            string crie = Son.ToUpper();

            return $"Le {Espece} {Nom} CRIE de toutes ses forces: \"{crie}!!!\"";
        }
    }
}
