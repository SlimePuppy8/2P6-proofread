﻿namespace Exercice2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Animal[] animaux =
            {
                new Animal("Ghost", (TypeAnimal)99),
                new Animal("Mia", TypeAnimal.Chat),
                new Animal("Snoopy", TypeAnimal.Chien),
                new Animal("Simba", TypeAnimal.Lion),
                new Animal("Gary", TypeAnimal.Serpent)
            };


            Console.WriteLine("Voici les animaux qui PARLENT:");
            foreach (var animal in animaux)
            {
                Console.WriteLine(animal.Parler());
            }
            Console.WriteLine();
            Console.WriteLine();


            Console.WriteLine("Voici les animaux qui CRIENT:");
            foreach (var animal in animaux)
            {
                Console.WriteLine(animal.Crier());
            }
            Console.WriteLine();
            Console.WriteLine();
        }    
    }
}
