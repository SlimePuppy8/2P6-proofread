﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AppPersonne
{
    public enum TypeRecherche
    {
        Nas,
        Nom,
        Prenom
        
    }

    /// ------------------------------------------------------------------------------
    /// <summary>
    ///	 Représente une personne : son numéro d'assurance sociale, son nom, son prénom et son age.
    /// </summary>
    /// ------------------------------------------------------------------------------
    public class Personne
    {
        public const string NAS_PAR_DEFAUT = "Inconnu";
        public const string PRENOM_PAR_DEFAUT = "Inconnu";
        public const string NOM_PAR_DEFAUT = "Inconnu";
        public const int AGE_PAR_DEFAUT = 18;
        //------------------------------------------------------
        private string m_nas;
        /// ----------------------------------------------------
        /// <summary>
        /// Obtient et définit le numéro sociale d'une personne.
        /// </summary>
        /// ----------------------------------------------------
        public string Nas
        {
            get { return m_nas; }
            private set
            {
                if(value ==null || value.Length < 9)
                {
                    m_nas = NAS_PAR_DEFAUT;
                }
                m_nas = value;
            }
        }

        //------------------------------------------------------
        private string m_nom;
        /// ----------------------------------------------------
        /// <summary>
        /// Obtient et définit le nom d'une personne.
        /// </summary>
        /// ----------------------------------------------------
        public string Nom
        {
            get { return m_nom; }
            private set
            {
                if (value == null || value.Length < 3)
                {
                    Nom = NOM_PAR_DEFAUT;
                }
                m_nom = value;
            }
        }
        //------------------------------------------------------
        private string m_prenom;
        /// ----------------------------------------------------
        /// <summary>
        /// Obtient et définit le prénom d'une personne.
        /// </summary>
        /// ----------------------------------------------------
        public string Prenom
        {
            get { return m_prenom; }
            private set
            {
                if (value == null || value.Length < 3)
                {
                    Prenom = PRENOM_PAR_DEFAUT;
                }
                m_prenom = value;
            }
        }
        //------------------------------------------------------
        private int m_age;
        /// ----------------------------------------------------
        /// <summary>
        /// Obtient et définit l'age d'une personne.
        /// </summary>
        /// ----------------------------------------------------
        public int Age
        {
            get { return m_age; }
            private set
            {
                if (value < 0)
                {
                    Age = AGE_PAR_DEFAUT;
                }
                m_age = value;
            }
        }
        //---------------------------------------------------------------
        /// <summary>
        /// Instancie une personne avec les données passées en paramètre.
        /// </summary>
        /// <param name="pNas">nas de la personne à créer</param>
        /// <param name="pNom">nom de la personne à créer</param>
        /// <param name="pPrenom">prénom de la personne à créer</param>
        /// <param name="pAge">age de la personne à créer</param>
        /// -------------------------------------------------------------
        public Personne(string pNas,  string pPrenom , string pNom, int pAge)
        {
            Nas = pNas;
            Prenom = pPrenom;
            Nom = pNom;
            Age = pAge;
        }
        //----------------------------------------------------------------------------------
        /// <summary>
        /// Instancie une personne avec  la chaîne passée en paramètre.
        /// Les données sont séparées par une virgule, voici un exemple:
        ///              NAS, prenom, nom.
        /// </summary>
        /// <param name="pChaineInfos">chaine des données séparées par une virgule</param>
        /// ---------------------------------------------------------------------------------
        public Personne(string pChaineInfos)
        {
            string[] tabInfos = pChaineInfos.Split(',');
          
            Nas = tabInfos[0];
            Prenom = tabInfos[1];
            Nom = tabInfos[2];
            bool estValide = int.TryParse(tabInfos[2], out int age);
            Age = age;

        }
    }
}
