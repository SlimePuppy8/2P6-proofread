﻿// Décommenter pour activer les tests d'une méthode
//#define TEST_EST_DANS_LA_LISTE
//#define TEST_AJOUTER_PERSONNE
//#define TEST_SUPPRIMER_PERSONNE
//#define TEST_FILTRER_AGE
//#define TEST_MOYENNE_AGE
//#define TEST_RECHERCHE
//#define TEST_SAUVEGARDER
//#define TEST_CHARGER



using System;
using System.Collections.Generic;
using System.IO;
using AppPersonne;


public static class TestsPersonnes
{
    public static int totalTests = 0;
    public static int testsReussis = 0;

   
    

    #region Tests de validation
    // ==========================================================
    static void AfficherResultat(bool condition)
    {
        totalTests++;

        if (condition)
        {
            testsReussis++;
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("OK");
        }
        else
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("ERREUR");
        }

        Console.ResetColor();
    }

    // ==========================================================
    static List<Personne> CreerListeTest()
    {
        return new List<Personne>()
        {
            new Personne("100000001", "Jean", "Dupont", 30),
            new Personne("100000002", "Marie", "Tremblay", 25),
            new Personne("100000003", "Paul", "Martin", 40),
            new Personne("100000004", "Sophie", "Lefebvre", 35),
            new Personne("100000005", "Luc", "Gagnon", 28),
            new Personne("100000006", "Isabelle", "Roy", 32),
            new Personne("100000007", "Marc", "Bouchard", 45),
            new Personne("100000008", "Julie", "Pelletier", 22),
            new Personne("100000009", "Pierre", "Côté", 50),
            new Personne("100000010", "Nathalie", "Lavoie", 27),
            new Personne("100000011", "François", "Morin", 38),
            new Personne("100000012", "Annie", "Fortin", 29),
            new Personne("100000013", "David", "Gauthier", 41),
            new Personne("100000014", "Karine", "Ouellet", 33),
            new Personne("100000015", "Éric", "Lapointe", 36),
            new Personne("100000016", "Mélanie", "Deschamps", 24),
            new Personne("100000017", "Alexandre", "Cloutier", 31),
            new Personne("100000018", "Catherine", "Beaulieu", 26),
            new Personne("100000019", "Stéphane", "Girard", 44),
            new Personne("100000020", "Valérie", "Poirier", 34)
        };
    }
  
    // ==========================================================
    public static void TestEstDansLaListe()
    {
#if TEST_EST_DANS_LA_LISTE
        Console.WriteLine("\n===== TEST EstDansLaListe =====");
        var liste = CreerListeTest();

        AfficherResultat(Program.EstDansLaListe("100000001", liste));
        AfficherResultat(!Program.EstDansLaListe("999999999", liste));
#endif
    }

    // ==========================================================
    public static void TestAjouterPersonne()
    {
              
#if TEST_AJOUTER_PERSONNE
        Console.WriteLine("\n===== TEST AjouterPersonne =====");
        var liste = CreerListeTest();

        AfficherResultat(
            Program.AjouterPersonne("100000021", "Test", "Test", 20, liste)
            && liste.Count == 21);

        AfficherResultat(
            !Program.AjouterPersonne("100000001", "Jean", "Dupont", 30, liste));

        AfficherResultat(
            !Program.AjouterPersonne("123", "A", "AB", -1, liste));
#endif
    }

    // ==========================================================
    public static void TestSupprimerPersonne()
    {
                
#if TEST_SUPPRIMER_PERSONNE
        Console.WriteLine("\n===== TEST SupprimerPersonne =====");
        var liste = CreerListeTest();

        AfficherResultat(
            Program.SupprimerPersonne(0, liste)
            && liste.Count == 19);

        AfficherResultat(
            !Program.SupprimerPersonne(100, liste));
#endif 
    }

    // ==========================================================
    public static void TestFiltrerSelonTrancheAge()
    {
     
#if TEST_FILTRER_AGE
        Console.WriteLine("\n===== TEST FiltrerSelonTrancheAge =====");
        var liste = CreerListeTest();

        var filtres = Program.FiltrerSelonTrancheAge(30, 40, liste);

        AfficherResultat(filtres.Count == 9);
#endif 

    }

    // ==========================================================
    public static void TestMoyenneAge()
    {
     
#if TEST_MOYENNE_AGE
        Console.WriteLine("\n===== TEST MoyenneAge =====");
        var liste = CreerListeTest();

        double moyenne = Program.MoyenneAge(liste);

        AfficherResultat(Math.Abs(moyenne - 33.5) < 0.01);
#endif
    }

    // ==========================================================
    public  static void TestRecherche()
    {

#if TEST_RECHERCHE
        Console.WriteLine("\n===== TEST Recherche =====");
        var liste = CreerListeTest();

        AfficherResultat(
            Program.Recherche(liste, TypeRecherche.Nom, "Martin") != null);

        AfficherResultat(
            Program.Recherche(liste, TypeRecherche.Nas, "100000010") != null);

        AfficherResultat(
            Program.Recherche(liste, TypeRecherche.Prenom, "Inexistant") == null);
#endif
    }

    // ==========================================================
    public static void TestSauvegarder()
    {
               
#if TEST_SAUVEGARDER
        Console.WriteLine("\n===== TEST Sauvegarder =====");

        var liste = CreerListeTest();
        string fichier = "testPersonnes.csv";

        Program.Sauvegarder(fichier, liste);

        List<Personne> nouvelleListe = new List<Personne>();
        Program.Charger(fichier, nouvelleListe);

        // 3) Vérification BRUTE (non réutilisable, volontairement)
        bool ok = true;

        if (liste.Count != 3)
        {
            ok = false;
        }
        else
        {
            // Lecture directe du fichier, sans structure élégante
            string[] lignes = File.ReadAllLines(fichier);

            for (int i = 0; i < lignes.Length; i++)
            {
                string[] données = lignes[i].Split(',');

                if (liste[i].Nas != données[0] ||
                    liste[i].Prenom != données[1] ||
                    liste[i].Nom != données[2] ||
                    liste[i].Age != int.Parse(données[3]))
                {
                    ok = false;
                    break;
                }
            }
        }

        AfficherResultat(nouvelleListe.Count == 20);
#endif
    }
    public static void TestCharger()
    {
#if TEST_CHARGER
    Console.WriteLine("\n===== TEST Charger =====");

    // 1) Préparer un fichier de test
    string fichier = "testChargement.csv";
    File.WriteAllLines(fichier, new string[]
    {
        "111,Jean,Tremblay,20",
        "222,Marie,Gagnon,30",
        "333,Luc,Martin,40"
    });

    // 2) Appeler la méthode à tester
    List<Personne> liste = new List<Personne>();
    Program.Charger(fichier, liste);

    // 3) Vérification BRUTE (non réutilisable, volontairement)
    bool ok = true;

    if (liste.Count != 3)
    {
        ok = false;
    }
    else
    {
        // Lecture directe du fichier, sans structure élégante
        string[] lignes = File.ReadAllLines(fichier);

        for (int i = 0; i < lignes.Length; i++)
        {
            string[] morceaux = lignes[i].Split(',');

            if (liste[i].Nas != morceaux[0] ||
                liste[i].Prenom != morceaux[1] ||
                liste[i].Nom != morceaux[2] ||
                liste[i].Age != int.Parse(morceaux[3]))
            {
                ok = false;
                break;
            }
        }
    }

    AfficherResultat(ok);
#endif
    }

    #endregion
}
