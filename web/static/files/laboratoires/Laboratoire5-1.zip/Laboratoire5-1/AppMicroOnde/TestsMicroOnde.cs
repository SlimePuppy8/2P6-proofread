﻿//#define TEST_CLASSE_MICR_OONDES
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.SqlServer.Server;

namespace AppMicroOnde
{
    internal class TestsMicroOnde
    {
        public static int totalTests = 0;
        public static int testsReussis = 0;

        #region Tests de validation
        // ==========================================================
        static void AfficherResultat(bool condition)
        {
            totalTests++;

            if (condition)
            {
                testsReussis++;
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("OK");
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("ERREUR");
            }

            Console.ResetColor();
        }
        
        // ==========================================================
        public static void TestConstructeurs()
        {
#if TEST_CLASSE_MICR_OONDES
            Console.WriteLine("\n===== TEST Constructeurs =====");

            // test constructeur par défaut
            MicroOnde moDefault = new MicroOnde();

            // test constructeur avec paramètre null            
            MicroOnde moNull = new MicroOnde("");

            // test constructeur avec paramètre
            const string ENDROIT = "salle des profs";
            MicroOnde moLocation = new MicroOnde(ENDROIT);

            AfficherResultat( moDefault.Emplacement == MicroOnde.EMPLACEMENT_PAR_DEFAUT);
            AfficherResultat( moDefault.MinutesCuisson == 0);
            AfficherResultat( moDefault.EstEnMarche == false );

            AfficherResultat( moNull.Emplacement == MicroOnde.EMPLACEMENT_PAR_DEFAUT);
            AfficherResultat( moLocation.Emplacement == ENDROIT);
            
#endif
        }

        public static void TestFonctionnementNormal()
        {
#if TEST_CLASSE_MICR_OONDES
            Console.WriteLine("\n===== TEST Fonctionnement Normal =====");

            // test fonctionnement avec micro-onde par défaut
            MicroOnde moDefault = new MicroOnde();
            AfficherResultat(moDefault.EstEnMarche == false);
            
            // test démarrer
            const int NB_MINUTES = 777;
            moDefault.Demarrer(NB_MINUTES);
            AfficherResultat(moDefault.EstEnMarche == true);
            AfficherResultat(moDefault.MinutesCuisson == NB_MINUTES);
            AfficherResultat(moDefault.ModeCuisson == MicroOnde.MODE_PAR_DEFAUT);

            // test arreter
            moDefault.Arreter();
            AfficherResultat(moDefault.EstEnMarche == false);
#endif
        }

        public static void TestFonctionnementAvecMode()
        {
#if TEST_CLASSE_MICR_OONDES
            Console.WriteLine("\n===== TEST Fonctionnement avec Mode =====");

            // test fonctionnement avec micro-onde par défaut
            MicroOnde moDefault = new MicroOnde();
            
            // test démarrer
            const int NB_MINUTES =666;
            const ModeCuisson MODE = ModeCuisson.Decongelation;

            moDefault.Demarrer(MODE,NB_MINUTES);

            AfficherResultat(moDefault.EstEnMarche == true);
            AfficherResultat(moDefault.MinutesCuisson == NB_MINUTES);
            AfficherResultat(moDefault.ModeCuisson == MODE);            
#endif
        }

        public static void TestFonctionnementMinuteInvalide()
        {
#if TEST_CLASSE_MICR_OONDES
            Console.WriteLine("\n===== TEST Fonctionnement Minute Invalide =====");

            // test fonctionnement avec micro-onde par défaut
            MicroOnde moDefault = new MicroOnde();
            
            // test démarrer
            const int NB_MINUTES_INVALIDES = -1;            

            moDefault.Demarrer(NB_MINUTES_INVALIDES);
                        
            AfficherResultat(moDefault.MinutesCuisson == MicroOnde.MINUTES_PAR_DEFAUT);
#endif
        }
       
        public static void TestFonctionnementConsommation()
        {
#if TEST_CLASSE_MICR_OONDES
            Console.WriteLine("\n===== TEST Fonctionnement Consommation =====");
            const int NB_MINUTES = 13;

            MicroOnde moDecongelation = new MicroOnde();
            moDecongelation.Demarrer(ModeCuisson.Decongelation, NB_MINUTES);
            AfficherResultat(moDecongelation.ConsommationWattsParCuisson == MicroOnde.WATTS_DECONGELATION * NB_MINUTES);

            MicroOnde moRechauffage = new MicroOnde();
            moRechauffage.Demarrer(ModeCuisson.Rechauffage, NB_MINUTES);
            AfficherResultat(moRechauffage.ConsommationWattsParCuisson == MicroOnde.WATTS_RECHAUFFAGE * NB_MINUTES);

            MicroOnde moGrill = new MicroOnde();
            moRechauffage.Demarrer(ModeCuisson.Grill, NB_MINUTES);
            AfficherResultat(moRechauffage.ConsommationWattsParCuisson == MicroOnde.WATTS_GRILL * NB_MINUTES);
#endif
        }

        #endregion
    }
}
