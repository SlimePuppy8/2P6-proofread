﻿using System;
using AppMicroOnde;

namespace AppCuisine
{
    class Program
    {
        static void Main(string[] args)
        {
            #region NE PAS MODIFIER
            TestsMicroOnde.TestConstructeurs();
            TestsMicroOnde.TestFonctionnementNormal();
            TestsMicroOnde.TestFonctionnementAvecMode();
            TestsMicroOnde.TestFonctionnementMinuteInvalide();
            TestsMicroOnde.TestFonctionnementConsommation();


            Console.WriteLine("\n===================================");
            Console.WriteLine($"RÉSULTAT FINAL : {TestsMicroOnde.testsReussis} / {TestsMicroOnde.totalTests}");
            Console.WriteLine("===================================");

            Console.ReadLine();
            #endregion
        }

    }
}
