﻿using System;
using System.Collections.Generic;
using System.IO;
using AppPersonne;

//#define TEST_EST_DANS_LA_LISTE

class Program
{
    public const string LISTE_DES_PERSONNES = "Fichiers\\ListeDesPersonnes.txt";

    static private List<Personne> m_colPersonnes = new List<Personne>();

  
    static void Main(string[] args)
    {
        #region NE PAS MODIFIER
        TestsPersonnes.TestEstDansLaListe();
        TestsPersonnes.TestAjouterPersonne();
        TestsPersonnes.TestSupprimerPersonne();
        TestsPersonnes.TestFiltrerSelonTrancheAge();
        TestsPersonnes.TestMoyenneAge();
        TestsPersonnes.TestRecherche();
        TestsPersonnes.TestSauvegarder();
        TestsPersonnes.TestCharger();

        Console.WriteLine("\n===================================");
        Console.WriteLine($"RÉSULTAT FINAL : {TestsPersonnes.testsReussis} / {TestsPersonnes.totalTests}");
        Console.WriteLine("===================================");

        Console.ReadLine();
        #endregion
    }

    #region Méthodes à implémenter

    /// <summary>
    /// TODO 01 : Définir une méthode AjouterPersonne EstDansLaListe qui vérifie si une personne existe déjà dans la liste selon son NAS.
    /// La comparaison est effectuée sans tenir compte des majuscules/minuscules.
    /// </summary>
    /// <param name="nas">
    /// Numéro d'assurance sociale à rechercher.
    /// </param>
    /// <param name="listePersonnes">
    /// Liste des personnes dans laquelle effectuer la recherche.
    /// </param>
    /// <returns>
    /// Retourne true si une personne avec le NAS fourni est trouvée,
    /// sinon retourne false.
    /// </returns>
    static public bool EstDansLaListe(string nas, List<Personne> listePersonnes)
    {
        

        return false;
    }
    /// <summary>
    /// TODO 02 : Définir une méthode AjouterPersonne qui ajoute une nouvelle personne dans la liste si les données sont valides
    /// et si le NAS n'existe pas déjà.
    /// </summary>


    /// <summary>
    /// TODO 03 : Définir une méthode SupprimerPersonne qui supprime une personne de la liste selon son index.
    /// </summary>

    /// <summary>
    /// TODO 04 : Définir une méthode FiltrerSelonTrancheAge qui retourne une nouvelle liste contenant uniquement les personnes
    /// dont l'âge se situe entre ageMin et ageMax inclusivement.
    /// </summary>

    /// <summary>
    /// TODO 05 : Définir une méthode MoyenneAge qui calcule et retourne la moyenne d'âge des personnes dans la liste.
    /// </summary>


    /// <summary>
    /// TODO 06 : Définir une méthode Recherche qui recherche une personne dans une liste selon un type de recherche
    /// (Nom, Prenom ou Nas) et une valeur donnée.
    /// </summary>


    /// <summary>
    /// TODO 07 : Définir une méthode Sauvegarder qui sauvegarde la liste des personnes dans un fichier texte.
    /// Chaque personne est enregistrée sur une ligne
    /// sous le format : NAS,Prénom,Nom,Age
    /// </summary>



    /// <summary>
    /// TODO 08 : Définir une méthode Charger qui récupère les personnes à partir d'un fichier texte
    /// et les ajoute dans la liste fournie.
    /// </summary>
   


    #endregion


}
















